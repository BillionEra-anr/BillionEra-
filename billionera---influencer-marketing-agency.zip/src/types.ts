export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  badge?: string;
  features: string[];
}

export interface CreatorReview {
  id: string;
  brandName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface CreatorItem {
  id: string;
  name: string;
  niche: string; // e.g. "Fashion", "Lifestyle", "Food", "Beauty"
  followers: string;
  engagement: string;
  image: string;
  platforms: string[];
  recentBrand?: string;
  instagramUrl?: string;
  instagramUsername?: string;
  city?: string;
  languages?: string[];
  bio?: string;
  contactInfo?: string;
  mediaKitUrl?: string;
  reach?: string;
  reviews?: CreatorReview[];
  // AI audit metrics
  contactEmail?: string;
  contactPhone?: string;
  avgLikes?: string;
  avgComments?: string;
  postingFrequency?: string;
  contentStyle?: string;
  audienceQuality?: string;
  creatorQuality?: string;
  fakeFollowerRisk?: string;
  brandSuitability?: string;
  recommendedCampaigns?: string[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  avatar: string;
  rating: number;
  niche: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface BenefitItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface StepItem {
  stepNumber: number;
  title: string;
  description: string;
  duration: string;
}
