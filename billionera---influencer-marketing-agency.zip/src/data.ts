import { ServiceItem, CreatorItem, TestimonialItem, FAQItem, BenefitItem, StepItem } from './types';

export const SERVICES: ServiceItem[] = [
  {
    id: 'influencer-marketing',
    title: 'Influencer Marketing',
    description: 'Data-driven, end-to-end influencer marketing campaigns. We match your D2C brand with high-performing creators to drive massive engagement and direct sales.',
    iconName: 'Sparkles',
    badge: 'Popular',
    features: ['Custom creator pairing', 'ROI-focused campaigns', 'Comprehensive analytics']
  },
  {
    id: 'creator-discovery',
    title: 'Creator Discovery',
    description: 'We manually vet and discover niche creators matching your exact target persona. No bots, no bloated numbers—only creators with real engagement.',
    iconName: 'Search',
    features: ['Manual content audits', 'Verified demographics', 'Niche-specific filtering']
  },
  {
    id: 'campaign-management',
    title: 'Campaign Management',
    description: 'From onboarding, brief creations, product shipments, content approvals, to publishing—we manage the entire operational lifecycle of your campaign.',
    iconName: 'Layers',
    badge: 'All-inclusive',
    features: ['Dedicated campaign managers', 'Legal & contract handling', 'Timely delivery checks']
  },
  {
    id: 'ugc-content',
    title: 'UGC Content Campaigns',
    description: 'Acquire high-converting User Generated Content (UGC) for your social media handles, website, and meta ads. Authentic reviews that build instant trust.',
    iconName: 'Video',
    features: ['Ad-optimized hook variations', 'High-quality product shots', 'Broad usage rights']
  },
  {
    id: 'product-launches',
    title: 'Product Launch Campaigns',
    description: 'Create explosive noise on social media for your new product launches. We choreograph coordinated posts to trend across target platforms.',
    iconName: 'Rocket',
    badge: 'High Impact',
    features: ['Coordinated drop timing', 'Unboxing experiences', 'Viral-centric challenges']
  },
  {
    id: 'brand-awareness',
    title: 'Brand Awareness Campaigns',
    description: 'Position your brand in front of millions of active buyers. Establish steady visual recall and prestige through sustained high-relevance integrations.',
    iconName: 'Target',
    features: ['High-reach mega-influencers', 'Multi-channel presence', 'Brand narrative alignment']
  }
];

export const CREATORS: CreatorItem[] = [
  {
    id: 'creator-1',
    name: 'Ananya Sharma',
    niche: 'Fashion',
    followers: '450K+',
    engagement: '8.4%',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80',
    platforms: ['Instagram', 'YouTube'],
    recentBrand: 'Myntra, Nykaa',
    instagramUsername: 'ananya_wear',
    instagramUrl: 'https://instagram.com/ananya_wear',
    city: 'Mumbai',
    languages: ['English', 'Hindi'],
    bio: 'Premium streetwear and editorial styling enthusiast. Helping brands craft modern visual stories with high-conversion appeal.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-1-1',
        brandName: 'Stitch & Co. Apparel',
        rating: 5,
        comment: 'Ananya delivered a phenomenal Reel. Her streetwear styling was highly original, aesthetic, and drove remarkable saves and comments from target shoppers!',
        date: '2026-06-15'
      },
      {
        id: 'rev-1-2',
        brandName: 'Zivame India',
        rating: 4,
        comment: 'Highly professional creator. Submitted drafts right on schedule and integrated product benefits naturally.',
        date: '2026-05-20'
      }
    ]
  },
  {
    id: 'creator-2',
    name: 'Rohan Mehta',
    niche: 'Lifestyle',
    followers: '280K+',
    engagement: '7.1%',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=500&q=80',
    platforms: ['Instagram', 'Threads'],
    recentBrand: 'Zomato, Cult.fit',
    instagramUsername: 'rohan_mehta',
    instagramUrl: 'https://instagram.com/rohan_mehta',
    city: 'Delhi',
    languages: ['Hindi', 'English'],
    bio: 'Exploring luxury lifestyle, travel spots, and personal wellness across urban India. Dedicated to daily organic storytelling.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-2-1',
        brandName: 'Zomato India',
        rating: 5,
        comment: 'Rohan is a natural narrator. His video on premium city escapes was perfectly paced, and drove a noticeable spike in app sign-ups!',
        date: '2026-06-02'
      }
    ]
  },
  {
    id: 'creator-3',
    name: 'Kriti Deshmukh',
    niche: 'Beauty',
    followers: '320K+',
    engagement: '9.2%',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80',
    platforms: ['Instagram', 'YouTube'],
    recentBrand: 'mCaffeine, Plum',
    instagramUsername: 'kriti_glow',
    instagramUrl: 'https://instagram.com/kriti_glow',
    city: 'Bangalore',
    languages: ['English', 'Kannada', 'Hindi'],
    bio: 'Authentic skincare breakdowns, shade matching, and clean beauty routines. Highly engaged south and central Indian demographic.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-3-1',
        brandName: 'Nexa Organic Skincare',
        rating: 5,
        comment: 'Absolute star. Her morning routine video felt 100% genuine and organic. We sold out of our primary serums within 10 days of her Reel going live!',
        date: '2026-06-28'
      },
      {
        id: 'rev-3-2',
        brandName: 'Plum Goodness',
        rating: 5,
        comment: 'Excellent close-up shots showing texture and application. Her followers trust her implicitly, which translates directly to solid engagement and brand recall.',
        date: '2026-05-11'
      }
    ]
  },
  {
    id: 'creator-4',
    name: 'Kabir Kapoor',
    niche: 'Food',
    followers: '510K+',
    engagement: '6.8%',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=80',
    platforms: ['YouTube', 'Instagram'],
    recentBrand: 'The Whole Truth, Swiggy',
    instagramUsername: 'kabir_bites',
    instagramUrl: 'https://instagram.com/kabir_bites',
    city: 'Mumbai',
    languages: ['Hindi', 'English'],
    bio: 'Baking and aesthetic gourmet plating instructions. Unlocking bold Indian spices and modern culinary secrets.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-4-1',
        brandName: 'The Whole Truth',
        rating: 5,
        comment: 'Kabir made an outstanding protein baking tutorial that was both educational and super entertaining. Authentic branding integrated perfectly.',
        date: '2026-06-19'
      }
    ]
  },
  {
    id: 'creator-5',
    name: 'Diya Patel',
    niche: 'Lifestyle',
    followers: '190K+',
    engagement: '11.3%',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=500&q=80',
    platforms: ['Instagram', 'Pinterest'],
    recentBrand: 'Nestasia, Chumbak',
    instagramUsername: 'diya_decor',
    instagramUrl: 'https://instagram.com/diya_decor',
    city: 'Ahmedabad',
    languages: ['Gujarati', 'Hindi', 'English'],
    bio: 'Minimalist decor, zero-waste living tips, and architectural design hacks for clean modern homes.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-5-1',
        brandName: 'Nestasia Home',
        rating: 5,
        comment: 'Diya’s eye for aesthetics is unmatched. The unboxing of our ceramic kitchen organizers received great reception and comments from design enthusiasts!',
        date: '2026-06-10'
      }
    ]
  },
  {
    id: 'creator-6',
    name: 'Aisha Khan',
    niche: 'Fashion',
    followers: '110K+',
    engagement: '10.5%',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=500&q=80',
    platforms: ['Instagram'],
    recentBrand: 'Zara, Ajio',
    instagramUsername: 'aisha_styled',
    instagramUrl: 'https://instagram.com/aisha_styled',
    city: 'Delhi',
    languages: ['English', 'Urdu', 'Hindi'],
    bio: 'Traditional and fusion apparel, festive wear, and sustainable thrifting guides for Gen-Z style seekers.',
    contactInfo: 'Available upon verification',
    mediaKitUrl: '#',
    reviews: [
      {
        id: 'rev-6-1',
        brandName: 'Ajio Luxe',
        rating: 5,
        comment: 'Aisha created an extremely high-engagement transition reel featuring our ethnic summer line. Prompt on communication and delightful to collaborate with!',
        date: '2026-06-25'
      }
    ]
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'testimonial-1',
    name: 'Simran Juneja',
    role: 'Founder',
    company: 'Nexa Organic Skincare',
    content: 'BillionEra transformed our D2C launch. They paired us with 12 lifestyle creators who shared authentic skin journeys. Our initial inventory sold out in just 10 days, with acquisition costs 40% lower than standard Meta ads.',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    rating: 5,
    niche: 'Beauty'
  },
  {
    id: 'testimonial-2',
    name: 'Vikramaditya Rao',
    role: 'Head of Growth',
    company: 'Stitch & Co. Apparel',
    content: 'We had struggled to find fashion creators who actually drive conversions rather than just likes. BillionEra’s curated creator selection was perfect. The reporting dashboard and seamless management allowed us to scale easily.',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80',
    rating: 5,
    niche: 'Fashion'
  },
  {
    id: 'testimonial-3',
    name: 'Pranav Bajaj',
    role: 'Co-Founder',
    company: 'Sprout Foods',
    content: 'Unbelievably fast execution. Within 14 days, our healthy snacks were featured in 20+ aesthetic recipe reels across India. Our website traffic surged by 300% and we received thousands of direct queries.',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
    rating: 5,
    niche: 'Food'
  }
];

export const STEPS: StepItem[] = [
  {
    stepNumber: 1,
    title: 'Tell Us About Your Brand',
    description: 'Share your campaign objectives, target audience, preferred niches, and campaign budget. We analyze your brand dna and find the visual sweet-spot.',
    duration: 'Within 24 Hours'
  },
  {
    stepNumber: 2,
    title: 'We Shortlist Suitable Creators',
    description: 'We dig into our network of 30+ verified premium creators to construct a customized portfolio of creators who share high alignment with your brand values.',
    duration: '3 - 5 Days'
  },
  {
    stepNumber: 3,
    title: 'Campaign Planning & Execution',
    description: 'We craft professional creative briefs, handle creator contracts, ship products, and oversee content creation with strict editorial standards before final posting.',
    duration: '7 - 10 Days'
  },
  {
    stepNumber: 4,
    title: 'Performance Tracking & Reporting',
    description: 'We track every reel, post, and video. You receive a detailed performance audit outlining direct clicks, saves, engagement benchmarks, and ROI analysis.',
    duration: 'Sustained Delivery'
  }
];

export const BENEFITS: BenefitItem[] = [
  {
    id: 'benefit-1',
    title: 'Carefully selected creators',
    description: 'We say no to generic database exports. Every single creator is meticulously evaluated for visual style, audience demographics, and real engagement metrics.',
    iconName: 'UserCheck'
  },
  {
    id: 'benefit-2',
    title: 'Campaigns tailored to your budget',
    description: 'Whether you are an emerging startup or a scaling brand, we customize creator mixes to generate maximum conversion leverage for your specific budget.',
    iconName: 'PiggyBank'
  },
  {
    id: 'benefit-3',
    title: 'Transparent communication',
    description: 'No hidden agency margins, no phantom pricing. You know exactly what creators charge, what goes to operations, and how your capital is utilized.',
    iconName: 'MessageSquare'
  },
  {
    id: 'benefit-4',
    title: 'Fast campaign execution',
    description: 'Our streamlined operational playbook eliminates email delays. We ship products fast, approve content smoothly, and go live exactly on schedule.',
    iconName: 'Zap'
  },
  {
    id: 'benefit-5',
    title: 'Authentic creator partnerships',
    description: 'We build premium, long-term friendships with creators. They love working with us, resulting in deeper dedication, higher posting value, and better pricing.',
    iconName: 'Heart'
  },
  {
    id: 'benefit-6',
    title: 'Professional campaign management',
    description: 'Forget managing 50 WhatsApp groups with creators. Our experienced campaign handlers take care of negotiations, briefs, and follow-ups.',
    iconName: 'Briefcase'
  }
];

export const FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'How does BillionEra work?',
    answer: 'We operate as an end-to-end partner. First, we outline your strategy. Next, we manually shortlist verified creators from our trusted network. Then, we coordinate contracts, briefs, shipping, and quality assurance. Finally, we go live and provide transparent metrics and ROI tracking.'
  },
  {
    id: 'faq-2',
    question: 'Which industries do you serve?',
    answer: 'While we specialize heavily in direct-to-consumer (D2C) brands in Fashion, Lifestyle, Food & Culinary, and Beauty, we also consult for premium wellness, travel, tech accessories, and smart home appliances.'
  },
  {
    id: 'faq-3',
    question: 'How do you select creators?',
    answer: 'We look way past follower counts. We perform manual content audits, check comments to verify real audience relationships, audit follower authenticity patterns, check historical campaign conversions, and ensure their visual aesthetic aligns with a premium brand standard.'
  },
  {
    id: 'faq-4',
    question: 'How much does influencer marketing cost?',
    answer: 'Influencer marketing campaigns are customizable. We design bespoke campaign packages based on your business stage, utilizing a strategic blend of highly engaged micro-influencers and mid-tier creators to maximize reach while staying highly cost-efficient.'
  },
  {
    id: 'faq-5',
    question: 'How long does a campaign take?',
    answer: 'A standard campaign takes between 14 to 21 days from your initial consultation to creator content going live. This includes creator alignment, briefing, sending product samples, content vetting, and scheduled deployment.'
  }
];
