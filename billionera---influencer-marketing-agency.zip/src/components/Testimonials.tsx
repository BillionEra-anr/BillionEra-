import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TestimonialItem } from '../types';
import { Star, Quote, Check, Sparkles } from 'lucide-react';

interface TestimonialsProps {
  darkMode: boolean;
  testimonials: TestimonialItem[];
  onAddTestimonial: (newReview: TestimonialItem) => void;
}

export default function Testimonials({ darkMode, testimonials, onAddTestimonial }: TestimonialsProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [company, setCompany] = useState('');
  const [niche, setNiche] = useState('Beauty');
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState('');
  const [avatar, setAvatar] = useState('');
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !role.trim() || !company.trim() || !content.trim()) {
      alert('Please fill out all required fields');
      return;
    }

    const defaultAvatars = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80'
    ];
    const finalAvatar = avatar.trim() || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];

    const newReview: TestimonialItem = {
      id: `testimonial-${Date.now()}`,
      name: name.trim(),
      role: role.trim(),
      company: company.trim(),
      content: content.trim(),
      avatar: finalAvatar,
      rating,
      niche
    };

    onAddTestimonial(newReview);
    setSuccess(true);
    
    // Reset form
    setName('');
    setRole('');
    setCompany('');
    setNiche('Beauty');
    setRating(5);
    setContent('');
    setAvatar('');

    setTimeout(() => {
      setSuccess(false);
      setIsFormOpen(false);
    }, 3500);
  };

  return (
    <section
      id="testimonials"
      className={`py-12 md:py-16 transition-colors duration-300 relative border-t border-b ${
        darkMode 
          ? 'bg-slate-900/20 border-slate-800/40' 
          : 'bg-white border-slate-200/40'
      }`}
    >
      {/* Background decoration */}
      <div className="absolute top-10 right-10 opacity-[0.02] dark:opacity-[0.03] pointer-events-none">
        <Quote className="h-64 w-64 text-[#22C55E]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-green-50 dark:bg-[#22C55E]/10 text-[#22C55E] border border-green-200/20 dark:border-transparent rounded-full text-xs font-bold uppercase tracking-tighter">
            <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
            Partner Feedback
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold tracking-tight">
            Verified Brand Partner Reviews
          </h2>
          <p className={`text-base leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>
            See how scaling startups are establishing visual authority and generating clear business returns with our creator network.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`p-8 rounded-3xl border relative transition-all duration-300 flex flex-col justify-between group hover:shadow-xl ${
                darkMode
                  ? 'bg-slate-900 border-slate-800 hover:border-[#22C55E]/40'
                  : 'bg-white border-slate-100 hover:border-[#22C55E]/40 shadow-sm'
              }`}
            >
              {/* Star Rating & Quote Accent */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-[#22C55E] text-[#22C55E]" />
                    ))}
                  </div>
                  <span className={`text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-md ${
                    darkMode ? 'bg-slate-950 text-slate-400' : 'bg-slate-50 text-slate-500'
                  }`}>
                    {item.niche} Niche
                  </span>
                </div>

                <p className={`text-sm leading-relaxed italic mb-8 ${
                  darkMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  "{item.content}"
                </p>
              </div>

              {/* Reviewer Profile */}
              <div className="flex items-center gap-3.5 border-t pt-6 border-slate-100 dark:border-slate-800">
                <div className="w-11 h-11 rounded-full overflow-hidden shrink-0 border border-slate-200 dark:border-slate-800">
                  <img referrerPolicy="no-referrer" src={item.avatar} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="text-sm font-bold leading-none">{item.name}</h4>
                  <p className={`text-xs mt-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {item.role}, <span className="font-semibold text-[#22C55E]">{item.company}</span>
                  </p>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

        {/* Review Submission Area */}
        <div className="mt-16 text-center space-y-6">
          <div className="flex justify-center">
            <button
              onClick={() => setIsFormOpen(!isFormOpen)}
              className="inline-flex items-center gap-2 px-6 py-3.5 bg-green-50 dark:bg-[#22C55E]/10 hover:bg-green-100 dark:hover:bg-[#22C55E]/20 text-[#22C55E] border border-green-200/40 dark:border-transparent rounded-2xl text-sm font-bold tracking-tight transition-all cursor-pointer shadow-md"
            >
              <Sparkles className="h-4 w-4 animate-pulse" />
              <span>{isFormOpen ? 'Cancel Submission' : 'Submit Your Brand Review'}</span>
            </button>
          </div>

          <AnimatePresence>
            {isFormOpen && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className={`max-w-xl mx-auto p-8 rounded-3xl border text-left space-y-6 ${
                  darkMode ? 'bg-slate-900/80 border-slate-800 backdrop-blur-md' : 'bg-slate-50 border-slate-200 shadow-md'
                }`}
              >
                <div>
                  <h3 className="text-lg font-bold font-display">Write a Review</h3>
                  <p className={`text-xs mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    Tell other startups how BillionEra has empowered your brand strategy.
                  </p>
                </div>

                {success ? (
                  <div className="p-6 rounded-2xl bg-[#22C55E]/15 border border-[#22C55E]/20 text-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-[#22C55E]/20 flex items-center justify-center text-[#22C55E] mx-auto">
                      <Check className="h-6 w-6" />
                    </div>
                    <h4 className="text-sm font-bold text-[#22C55E]">Review Published Successfully!</h4>
                    <p className={`text-xs ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                      Thank you for sharing your feedback. Your review is now live in the section above and visible to all users.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Your Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Priyanjali Sen"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                            darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                          }`}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Brand / Company *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Plum Goodness"
                          value={company}
                          onChange={(e) => setCompany(e.target.value)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                            darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Role / Title *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Founder, Head of Marketing"
                          value={role}
                          onChange={(e) => setRole(e.target.value)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                            darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                          }`}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Category / Niche *</label>
                        <select
                          value={niche}
                          onChange={(e) => setNiche(e.target.value)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                            darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                          }`}
                        >
                          <option value="Beauty">Beauty & Skincare</option>
                          <option value="Fashion">Fashion & Apparel</option>
                          <option value="Lifestyle">Lifestyle & Travel</option>
                          <option value="Food">Food & Beverage</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Avatar Image URL (Optional)</label>
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/photo-..."
                        value={avatar}
                        onChange={(e) => setAvatar(e.target.value)}
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                          darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                        }`}
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Rating Stars *</label>
                      <div className="flex items-center gap-1.5 pt-1">
                        {[1, 2, 3, 4, 5].map((starNum) => {
                          const isActive = hoverRating !== null ? starNum <= hoverRating : starNum <= rating;
                          return (
                            <button
                              key={starNum}
                              type="button"
                              onClick={() => setRating(starNum)}
                              onMouseEnter={() => setHoverRating(starNum)}
                              onMouseLeave={() => setHoverRating(null)}
                              className="p-1 transition-transform active:scale-90"
                            >
                              <Star
                                className={`h-6 w-6 transition-all ${
                                  isActive
                                    ? 'fill-[#22C55E] text-[#22C55E]'
                                    : 'text-slate-300 dark:text-slate-700'
                                }`}
                              />
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Your Success Review *</label>
                      <textarea
                        required
                        rows={3}
                        placeholder="Write details about your experience. How did the influencer campaigns perform?"
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border resize-none focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                          darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-950'
                        }`}
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-[#22C55E] text-slate-950 font-bold rounded-xl text-xs hover:bg-emerald-500 active:scale-[0.98] transition-all cursor-pointer shadow-md"
                    >
                      Publish Review Live
                    </button>
                  </form>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
