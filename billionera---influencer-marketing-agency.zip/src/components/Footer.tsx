import React, { useState } from 'react';
import { Mail, Instagram, MessageSquare, Send, ArrowUpRight, Check } from 'lucide-react';

interface FooterProps {
  darkMode: boolean;
  onNavigate: (sectionId: string) => void;
  siteSettings: {
    contactEmail: string;
    contactPhone: string;
    contactInstagram: string;
  };
}

export default function Footer({ darkMode, onNavigate, siteSettings }: FooterProps) {
  const [email, setEmail] = useState('');
  const [success, setSuccess] = useState(false);

  const waNumber = siteSettings.contactPhone.replace(/[^\d]/g, '');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) return;
    setSuccess(true);
    setTimeout(() => {
      setEmail('');
      setSuccess(false);
    }, 3000);
  };

  const nichesLinks = [
    { label: 'Fashion Influencers', target: 'creators' },
    { label: 'Lifestyle Influencers', target: 'creators' },
    { label: 'Food Influencers', target: 'creators' },
    { label: 'Beauty Influencers', target: 'creators' },
  ];

  const quickLinks = [
    { label: 'Browse Creators', target: 'creators' },
    { label: 'Book Consultation', target: 'contact' },
  ];

  return (
    <footer
      id="main-footer"
      className={`border-t transition-colors duration-300 ${
        darkMode
          ? 'bg-slate-950 border-slate-900 text-slate-400'
          : 'bg-white border-slate-200 text-slate-600'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Column 1: Brand & Description */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center cursor-pointer group" onClick={() => onNavigate('hero')}>
              <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-[#22C55E] text-white font-display font-bold text-lg mr-2.5 shadow-md shadow-[#22C55E]/20">
                B
              </div>
              <span className={`font-display font-extrabold text-lg tracking-tight leading-none ${
                darkMode ? 'text-white' : 'text-slate-900'
              }`}>
                Billion<span className="text-[#22C55E]">Era</span>
              </span>
            </div>

            <p className="text-xs leading-relaxed max-w-sm">
              BillionEra is a premium influencer marketing agency in India. We design, coordinate, and execute ROI-focused creator campaigns that assist fast-growing D2C brands in capturing genuine attention and scaling direct sales.
            </p>

            {/* Social Channels */}
            <div className="flex items-center space-x-3.5 pt-1">
              <a
                href={siteSettings.contactInstagram}
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2.5 rounded-full border transition-colors ${
                  darkMode ? 'border-slate-800 hover:bg-slate-850 text-slate-300 hover:text-white' : 'border-slate-200 hover:bg-slate-50 text-slate-700 hover:text-slate-900'
                }`}
                aria-label="Instagram Channel"
              >
                <Instagram className="h-4.5 w-4.5" />
              </a>
              <a
                href={`mailto:${siteSettings.contactEmail}`}
                className={`p-2.5 rounded-full border transition-colors ${
                  darkMode ? 'border-slate-800 hover:bg-slate-850 text-slate-300 hover:text-white' : 'border-slate-200 hover:bg-slate-50 text-slate-700 hover:text-slate-900'
                }`}
                aria-label="Email Channel"
              >
                <Mail className="h-4.5 w-4.5" />
              </a>
              <a
                href={`https://wa.me/${waNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2.5 rounded-full border transition-colors ${
                  darkMode ? 'border-slate-800 hover:bg-slate-850 text-slate-300 hover:text-white' : 'border-slate-200 hover:bg-slate-50 text-slate-700 hover:text-slate-900'
                }`}
                aria-label="WhatsApp Channel"
              >
                <MessageSquare className="h-4.5 w-4.5" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Navigation */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-white' : 'text-slate-900'}`}>
              Navigation
            </h4>
            <ul className="space-y-2.5 text-xs">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => onNavigate(link.target)}
                    className="hover:text-[#22C55E] transition-colors cursor-pointer text-left focus:outline-none"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Services */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-white' : 'text-slate-900'}`}>
              Creator Niches
            </h4>
            <ul className="space-y-2.5 text-xs">
              {nichesLinks.map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => onNavigate(link.target)}
                    className="hover:text-[#22C55E] transition-colors cursor-pointer text-left focus:outline-none"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Newsletter / Contact Sign-up */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-white' : 'text-slate-900'}`}>
              Monthly Insights
            </h4>
            <p className="text-xs leading-relaxed">
              Subscribe to get creator database updates, D2C performance studies, and marketing guides.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="anand@brand.com"
                  className={`w-full px-4 py-3 rounded-full text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] pr-10 ${
                    darkMode
                      ? 'bg-slate-900 border-slate-800 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1.5 p-1.5 rounded-full bg-[#22C55E] text-white hover:bg-emerald-500 transition-colors cursor-pointer"
                  aria-label="Subscribe"
                >
                  {success ? <Check className="h-3.5 w-3.5 stroke-[2.5]" /> : <Send className="h-3.5 w-3.5" />}
                </button>
              </div>
              {success && (
                <p className="text-[10px] text-[#22C55E] font-bold flex items-center gap-1">
                  ✓ Successfully subscribed! Check your inbox soon.
                </p>
              )}
            </form>
          </div>

        </div>

        {/* Bottom Legal bar */}
        <div className={`mt-16 pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4 text-xs ${
          darkMode ? 'border-slate-900' : 'border-slate-200'
        }`}>
          <p>© {new Date().getFullYear()} BillionEra. All rights reserved. Made in India.</p>
          
          <div className="flex items-center space-x-6">
            <button
              onClick={() => onNavigate('contact')}
              className="hover:text-[#22C55E] transition-colors text-left"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="hover:text-[#22C55E] transition-colors text-left"
            >
              Terms & Conditions
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
