import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Lock, Unlock, Database, Plus, Trash2, Edit2, Save, 
  Sparkles, Shield, User, HelpCircle, FileText, Settings, 
  MessageSquare, Layers, AlertCircle, RefreshCw, Key, Eye, EyeOff, Copy, Check
} from 'lucide-react';
import { CreatorItem, ServiceItem, TestimonialItem, FAQItem } from '../types';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  
  creators: CreatorItem[];
  setCreators: React.Dispatch<React.SetStateAction<CreatorItem[]>>;
  
  services: ServiceItem[];
  setServices: React.Dispatch<React.SetStateAction<ServiceItem[]>>;
  
  testimonials: TestimonialItem[];
  setTestimonials: React.Dispatch<React.SetStateAction<TestimonialItem[]>>;
  
  faqs: FAQItem[];
  setFaqs: React.Dispatch<React.SetStateAction<FAQItem[]>>;
  
  siteSettings: {
    heroBadge: string;
    heroTitle: string;
    heroDescription: string;
    contactEmail: string;
    contactPhone: string;
    contactInstagram: string;
  };
  setSiteSettings: React.Dispatch<React.SetStateAction<{
    heroBadge: string;
    heroTitle: string;
    heroDescription: string;
    contactEmail: string;
    contactPhone: string;
    contactInstagram: string;
  }>>;
}

export default function AdminPanel({
  isOpen,
  onClose,
  darkMode,
  creators,
  setCreators,
  services,
  setServices,
  testimonials,
  setTestimonials,
  faqs,
  setFaqs,
  siteSettings,
  setSiteSettings
}: AdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordHint, setShowPasswordHint] = useState(false);
  const [activeTab, setActiveTab] = useState<'creators' | 'ai-import' | 'services' | 'testimonials' | 'faqs' | 'settings' | 'copy-paste'>('creators');

  // Form states for creating/editing
  const [editingCreator, setEditingCreator] = useState<CreatorItem | null>(null);
  const [newCreator, setNewCreator] = useState<Partial<CreatorItem>>({
    name: '',
    niche: '',
    followers: '',
    engagement: '',
    image: '',
    platforms: ['Instagram'],
    recentBrand: '',
    instagramUrl: '',
    instagramUsername: '',
    city: '',
    languages: [],
    bio: '',
    contactInfo: '',
    mediaKitUrl: '',
    reach: '',
    contactEmail: '',
    contactPhone: ''
  });

  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [editingTestimonial, setEditingTestimonial] = useState<TestimonialItem | null>(null);
  const [newTestimonial, setNewTestimonial] = useState<Partial<TestimonialItem>>({
    name: '',
    role: '',
    company: '',
    content: '',
    avatar: '',
    rating: 5,
    niche: 'Beauty'
  });

  const [editingFaq, setEditingFaq] = useState<FAQItem | null>(null);
  const [newFaq, setNewFaq] = useState<Partial<FAQItem>>({
    question: '',
    answer: ''
  });

  const [settingsForm, setSettingsForm] = useState(siteSettings);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === 'billionera123' || passcode.toLowerCase() === 'billionera') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Invalid passcode. Hint: Use "billionera123"');
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSiteSettings(settingsForm);
    // Visual alert
    alert('Site settings updated successfully!');
  };

  // Helper for image file uploading / drag and drop to base64 conversion
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image is too large. Please select an image under 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          callback(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Creator Actions
  const handleAddCreator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreator.name || !newCreator.followers) {
      alert('Please fill out all required fields');
      return;
    }
    const created: CreatorItem = {
      id: `creator-${Date.now()}`,
      name: newCreator.name || '',
      niche: newCreator.niche || 'Fashion',
      followers: newCreator.followers || '100K+',
      engagement: newCreator.engagement || '5.0%',
      image: newCreator.image || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80',
      platforms: newCreator.platforms || ['Instagram'],
      recentBrand: newCreator.recentBrand || '',
      instagramUrl: newCreator.instagramUrl || '',
      instagramUsername: newCreator.instagramUsername || '',
      city: newCreator.city || '',
      languages: newCreator.languages || ['English', 'Hindi'],
      bio: newCreator.bio || '',
      contactInfo: newCreator.contactInfo || '',
      mediaKitUrl: newCreator.mediaKitUrl || '',
      reach: newCreator.reach || '',
      contactEmail: newCreator.contactEmail || '',
      contactPhone: newCreator.contactPhone || ''
    };
    setCreators([created, ...creators]);
    setNewCreator({
      name: '',
      niche: '',
      followers: '',
      engagement: '',
      image: '',
      platforms: ['Instagram'],
      recentBrand: '',
      instagramUrl: '',
      instagramUsername: '',
      city: '',
      languages: [],
      bio: '',
      contactInfo: '',
      mediaKitUrl: '',
      reach: '',
      contactEmail: '',
      contactPhone: ''
    });
  };

  const handleUpdateCreator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCreator) return;
    setCreators(creators.map(c => c.id === editingCreator.id ? editingCreator : c));
    setEditingCreator(null);
  };

  const handleDeleteCreator = (id: string) => {
    if (confirm('Are you sure you want to remove this creator?')) {
      setCreators(creators.filter(c => c.id !== id));
    }
  };

  // Service Actions
  const handleUpdateService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingService) return;
    setServices(services.map(s => s.id === editingService.id ? editingService : s));
    setEditingService(null);
  };

  // Testimonial Actions
  const handleAddTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTestimonial.name || !newTestimonial.content) {
      alert('Please fill out all required fields');
      return;
    }
    const created: TestimonialItem = {
      id: `testimonial-${Date.now()}`,
      name: newTestimonial.name || '',
      role: newTestimonial.role || 'Founder',
      company: newTestimonial.company || '',
      content: newTestimonial.content || '',
      avatar: newTestimonial.avatar || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
      rating: newTestimonial.rating || 5,
      niche: newTestimonial.niche || 'Beauty'
    };
    setTestimonials([created, ...testimonials]);
    setNewTestimonial({
      name: '',
      role: '',
      company: '',
      content: '',
      avatar: '',
      rating: 5,
      niche: 'Beauty'
    });
  };

  const handleUpdateTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTestimonial) return;
    setTestimonials(testimonials.map(t => t.id === editingTestimonial.id ? editingTestimonial : t));
    setEditingTestimonial(null);
  };

  const handleDeleteTestimonial = (id: string) => {
    if (confirm('Are you sure you want to remove this testimonial?')) {
      setTestimonials(testimonials.filter(t => t.id !== id));
    }
  };

  // FAQ Actions
  const handleAddFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaq.question || !newFaq.answer) {
      alert('Please fill out all required fields');
      return;
    }
    const created: FAQItem = {
      id: `faq-${Date.now()}`,
      question: newFaq.question || '',
      answer: newFaq.answer || ''
    };
    setFaqs([...faqs, created]);
    setNewFaq({ question: '', answer: '' });
  };

  const handleUpdateFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFaq) return;
    setFaqs(faqs.map(f => f.id === editingFaq.id ? editingFaq : f));
    setEditingFaq(null);
  };

  const handleDeleteFaq = (id: string) => {
    if (confirm('Are you sure you want to remove this FAQ?')) {
      setFaqs(faqs.filter(f => f.id !== id));
    }
  };

  const resetAllToDefault = () => {
    if (confirm('WARNING: This will clear all your custom changes and restore default database values. Continue?')) {
      localStorage.removeItem('billionera_creators');
      localStorage.removeItem('billionera_services');
      localStorage.removeItem('billionera_testimonials');
      localStorage.removeItem('billionera_faqs');
      localStorage.removeItem('billionera_settings');
      window.location.reload();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div 
        onClick={onClose} 
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity" 
      />

      {/* Slider Panel Container */}
      <div className={`relative w-full max-w-4xl h-full flex flex-col shadow-2xl transition-all duration-300 ${
        darkMode ? 'bg-slate-900 border-l border-slate-800 text-white' : 'bg-white border-l border-slate-200 text-slate-900'
      }`}>
        
        {/* Header bar */}
        <div className={`p-6 border-b flex items-center justify-between shrink-0 ${
          darkMode ? 'border-slate-800 bg-slate-950/40' : 'border-slate-150 bg-slate-50'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#22C55E]/15 text-[#22C55E]">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display leading-none">BillionEra Control Console</h2>
              <p className={`text-[10px] font-mono mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isAuthenticated ? 'ADMIN ACTIVE SESSION' : 'SECURE GATEWAY ENFORCED'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className={`p-1.5 rounded-lg border transition-colors hover:bg-red-500/10 hover:text-red-500 ${
              darkMode ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'
            }`}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Auth Screening View */}
        {!isAuthenticated ? (
          <div className="flex-1 overflow-y-auto flex items-center justify-center p-8">
            <div className={`w-full max-w-md p-8 rounded-3xl border text-center space-y-6 ${
              darkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-150 shadow-sm'
            }`}>
              <div className="w-16 h-16 rounded-full bg-[#22C55E]/10 flex items-center justify-center text-[#22C55E] mx-auto">
                <Lock className="h-8 w-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-bold font-display">Authentication Required</h3>
                <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  Accessing the creator registries and copywriting systems requires passcode confirmation.
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4 text-left">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold">Passcode</label>
                    <button
                      type="button"
                      onClick={() => setShowPasswordHint(!showPasswordHint)}
                      className="text-[10px] text-[#22C55E] hover:underline cursor-pointer"
                    >
                      {showPasswordHint ? 'Hide Hint' : 'Reveal Passcode Hint?'}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={passcode}
                      onChange={(e) => setPasscode(e.target.value)}
                      placeholder="Enter admin passcode"
                      className={`w-full pl-4 pr-11 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                        authError ? 'border-red-500 bg-red-500/5' : darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-md hover:bg-slate-800/10 text-slate-400 hover:text-[#22C55E] transition-all cursor-pointer"
                      title={showPassword ? "Hide Passcode" : "Show Passcode"}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>

                  {showPasswordHint && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`p-3 rounded-xl border text-[10px] leading-relaxed ${
                        darkMode ? 'bg-[#22C55E]/5 border-[#22C55E]/10 text-slate-300' : 'bg-green-50/50 border-green-200 text-slate-700'
                      }`}
                    >
                      💡 <strong>Credential hint:</strong> The default secure password is <span className="font-mono font-bold text-[#22C55E] select-all">billionera123</span> or <span className="font-mono font-bold text-[#22C55E] select-all">billionera</span>.
                    </motion.div>
                  )}

                  {authError && (
                    <p className="text-[10px] text-red-500 flex items-center gap-1 mt-1 font-semibold">
                      <AlertCircle className="h-3.5 w-3.5" /> {authError}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[#22C55E] text-slate-950 font-bold hover:bg-emerald-500 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Unlock className="h-4 w-4" />
                  <span>Verify Identity</span>
                </button>
              </form>
            </div>
          </div>
        ) : (
          /* Logged In Dashboard Layout */
          <div className="flex-1 flex overflow-hidden">
            
            {/* Sidebar Navigation inside Panel */}
            <div className={`w-44 border-r flex flex-col justify-between shrink-0 ${
              darkMode ? 'border-slate-800 bg-slate-950/20' : 'border-slate-150 bg-slate-50'
            }`}>
              <div className="p-3.5 space-y-1.5">
                {[
                  { id: 'creators', label: 'Creators', icon: User },
                  { id: 'ai-import', label: 'Add Creator', icon: Plus },
                  { id: 'services', label: 'Services', icon: Layers },
                  { id: 'testimonials', label: 'Testimonials', icon: MessageSquare },
                  { id: 'faqs', label: 'FAQs', icon: HelpCircle },
                  { id: 'settings', label: 'Site Copy', icon: Settings },
                  { id: 'copy-paste', label: 'Copy-Paste Hub', icon: FileText }
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id as any);
                        setEditingCreator(null);
                        setEditingService(null);
                        setEditingTestimonial(null);
                        setEditingFaq(null);
                      }}
                      className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#22C55E]/15 text-[#22C55E]'
                          : darkMode
                            ? 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Maintenance Actions */}
              <div className="p-3.5 space-y-2">
                <button
                  onClick={resetAllToDefault}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-red-500/20 text-red-500 text-[10px] font-mono font-bold hover:bg-red-500/10 transition-all cursor-pointer"
                  title="Reset site content to default template values"
                >
                  <RefreshCw className="h-3 w-3" />
                  <span>Reset Content</span>
                </button>
                <button
                  onClick={() => setIsAuthenticated(false)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-semibold text-center border cursor-pointer ${
                    darkMode ? 'border-slate-800 text-slate-400 hover:bg-slate-900' : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Lock Panel
                </button>
              </div>
            </div>

            {/* Core Tab Dynamic Panels */}
            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              
              {/* Tab 1.5: Onboard Creator - Manual Form */}
              {activeTab === 'ai-import' && (
                <div className="space-y-8 text-left">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-extrabold font-display flex items-center gap-2">
                        <Plus className="h-5 w-5 text-[#22C55E]" />
                        Onboard New Creator
                      </h3>
                      <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        Manually enter creator details to list them instantly in the premium influencer network.
                      </p>
                    </div>
                  </div>

                  <form onSubmit={handleAddCreator} className={`p-6 rounded-2xl border space-y-6 ${
                    darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-white border-slate-150 shadow-sm'
                  }`}>
                    
                    {/* Profile Picture Upload Section */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Profile Picture *</label>
                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        {newCreator.image ? (
                          <img
                            referrerPolicy="no-referrer"
                            src={newCreator.image}
                            alt="Preview"
                            className="w-16 h-16 rounded-full object-cover border border-[#22C55E]"
                          />
                        ) : (
                          <div className="w-16 h-16 rounded-full bg-[#22C55E]/10 border border-dashed border-[#22C55E]/40 flex items-center justify-center text-[#22C55E] text-xs font-bold font-mono">
                            No Pic
                          </div>
                        )}
                        <div className="flex-1 w-full space-y-1.5">
                          <label className={`w-full flex flex-col items-center justify-center px-4 py-3 border border-dashed rounded-xl cursor-pointer transition-all text-center ${
                            darkMode 
                              ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900 hover:border-[#22C55E]/60' 
                              : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-[#22C55E]/60'
                          }`}>
                            <span className="text-xs font-bold text-[#22C55E]">📷 Upload Profile Picture</span>
                            <span className={`text-[9px] mt-0.5 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>PNG, JPG, WEBP up to 2MB</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleImageUpload(e, (base64) => setNewCreator({ ...newCreator, image: base64 }))}
                            />
                          </label>
                        </div>
                      </div>
                    </div>

                    {/* Identity & Socials Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Creator Name *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.name || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, name: e.target.value })}
                          placeholder="e.g. Ananya S."
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Username *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.instagramUsername || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, instagramUsername: e.target.value })}
                          placeholder="e.g. ananya_wear"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Link *</label>
                        <input
                          type="url"
                          required
                          value={newCreator.instagramUrl || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, instagramUrl: e.target.value })}
                          placeholder="e.g. https://instagram.com/ananya_wear"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Category *</label>
                        <select
                          required
                          value={newCreator.niche || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, niche: e.target.value })}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                          }`}
                        >
                          <option value="" disabled>Select Category</option>
                          {['Fashion', 'Lifestyle', 'Food', 'Beauty', 'Travel', 'Tech', 'Fitness'].map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Metrics Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Followers *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.followers || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, followers: e.target.value })}
                          placeholder="e.g. 450K or 1.2M"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Reach *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.reach || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, reach: e.target.value })}
                          placeholder="e.g. 850K"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Engagement Rate *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.engagement || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, engagement: e.target.value })}
                          placeholder="e.g. 8.4%"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Geography & Contact info */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">City *</label>
                        <input
                          type="text"
                          required
                          value={newCreator.city || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, city: e.target.value })}
                          placeholder="e.g. Mumbai"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Email *</label>
                        <input
                          type="email"
                          required
                          value={newCreator.contactEmail || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, contactEmail: e.target.value })}
                          placeholder="e.g. collabs@username.com"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Phone Number *</label>
                        <input
                          type="tel"
                          required
                          value={newCreator.contactPhone || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, contactPhone: e.target.value })}
                          placeholder="e.g. +91 98765 43210"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Biography */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Bio *</label>
                      <textarea
                        required
                        rows={3}
                        value={newCreator.bio || ''}
                        onChange={(e) => setNewCreator({ ...newCreator, bio: e.target.value })}
                        placeholder="Tell us about their content style, key brand niches, and vibe..."
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/50 ${
                          darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                        }`}
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="flex justify-end pt-4 border-t border-slate-800/10 dark:border-slate-800/30">
                      <button
                        type="submit"
                        className="px-6 py-3 bg-[#22C55E] hover:bg-emerald-500 text-slate-950 rounded-xl text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#22C55E]/15 cursor-pointer flex items-center gap-1.5"
                      >
                        <Plus className="h-4 w-4" />
                        Publish Creator Profile
                      </button>
                    </div>

                  </form>
                </div>
              )}

              {/* Tab 1: Creators Registry */}
              {activeTab === 'creators' && (
                <div className="space-y-8">
                  {/* Title Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-extrabold font-display">Creators Registry</h3>
                      <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        Add, modify or delete the creators listed in the interactive gallery.
                      </p>
                    </div>
                  </div>

                  {/* Creator Form - Edit or Add */}
                  {editingCreator ? (
                    <form onSubmit={handleUpdateCreator} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className="flex items-center justify-between border-b pb-2 border-slate-800/40">
                        <span className="text-xs font-bold text-[#22C55E]">Editing Creator: {editingCreator.name}</span>
                        <button 
                          type="button" 
                          onClick={() => setEditingCreator(null)}
                          className="text-[10px] font-mono text-slate-500 hover:text-red-500"
                        >
                          Cancel
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Name</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.name}
                            onChange={(e) => setEditingCreator({ ...editingCreator, name: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Niche Category</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.niche}
                            onChange={(e) => setEditingCreator({ ...editingCreator, niche: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Beauty & Skincare"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Followers Count</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.followers}
                            onChange={(e) => setEditingCreator({ ...editingCreator, followers: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. 450K+"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Engagement %</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.engagement}
                            onChange={(e) => setEditingCreator({ ...editingCreator, engagement: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. 8.4%"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Recent Brands</label>
                          <input
                            type="text"
                            value={editingCreator.recentBrand}
                            onChange={(e) => setEditingCreator({ ...editingCreator, recentBrand: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Myntra, Nykaa"
                          />
                        </div>
                      </div>

                      <div className="space-y-2 border border-slate-800/10 dark:border-slate-800/60 p-4.5 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Profile Picture *</label>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          {editingCreator.image ? (
                            <img
                              src={editingCreator.image}
                              alt="Preview"
                              className="w-14 h-14 rounded-full object-cover border border-[#22C55E]/40"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-14 h-14 rounded-full bg-[#22C55E]/10 border border-dashed border-[#22C55E]/40 flex items-center justify-center text-[#22C55E] text-xs font-bold font-mono">
                              No Pic
                            </div>
                          )}
                          <div className="flex-1 w-full space-y-1.5">
                            <label className={`w-full flex flex-col items-center justify-center px-4 py-3 border border-dashed rounded-xl cursor-pointer transition-all text-center ${
                              darkMode 
                                ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900 hover:border-[#22C55E]/60' 
                                : 'border-slate-300 bg-white hover:bg-slate-100 hover:border-[#22C55E]/60'
                            }`}>
                              <span className="text-xs font-bold text-[#22C55E]">📷 Upload Profile Picture</span>
                              <span className={`text-[9px] mt-0.5 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>PNG, JPG, WEBP up to 2MB</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => handleImageUpload(e, (base64) => setEditingCreator({ ...editingCreator, image: base64 }))}
                              />
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Username (without @) *</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.instagramUsername || ''}
                            onChange={(e) => setEditingCreator({ ...editingCreator, instagramUsername: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="ananya_sharma"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Profile Link / URL *</label>
                          <input
                            type="url"
                            required
                            value={editingCreator.instagramUrl || ''}
                            onChange={(e) => setEditingCreator({ ...editingCreator, instagramUrl: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. https://www.instagram.com/ananya_sharma"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">City / Location *</label>
                          <input
                            type="text"
                            required
                            value={editingCreator.city || ''}
                            onChange={(e) => setEditingCreator({ ...editingCreator, city: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. Mumbai"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Media Kit / Download URL</label>
                          <input
                            type="text"
                            value={editingCreator.mediaKitUrl || ''}
                            onChange={(e) => setEditingCreator({ ...editingCreator, mediaKitUrl: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. https://drive.google.com/..."
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Languages (comma-separated) *</label>
                          <input
                            type="text"
                            required
                            value={(editingCreator.languages || []).join(', ')}
                            onChange={(e) => setEditingCreator({ ...editingCreator, languages: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. English, Hindi"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Contact Information / Private Notes</label>
                          <input
                            type="text"
                            value={editingCreator.contactInfo || ''}
                            onChange={(e) => setEditingCreator({ ...editingCreator, contactInfo: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="Email, Phone, or Manager contact details"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Short Biography / Bio *</label>
                        <textarea
                          rows={3}
                          required
                          value={editingCreator.bio || ''}
                          onChange={(e) => setEditingCreator({ ...editingCreator, bio: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                          }`}
                          placeholder="Tell us about their style, key demographics, and audience vibe..."
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Platforms</label>
                        <div className="flex items-center gap-4 pt-1">
                          {['Instagram', 'YouTube', 'Threads', 'Pinterest'].map(p => {
                            const hasPlat = editingCreator.platforms.includes(p);
                            return (
                              <label key={p} className="flex items-center gap-1.5 text-xs cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={hasPlat}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setEditingCreator({
                                        ...editingCreator,
                                        platforms: [...editingCreator.platforms, p]
                                      });
                                    } else {
                                      setEditingCreator({
                                        ...editingCreator,
                                        platforms: editingCreator.platforms.filter(plat => plat !== p)
                                      });
                                    }
                                  }}
                                  className="accent-[#22C55E]"
                                />
                                <span>{p}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 flex items-center gap-1 cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Save Changes
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleAddCreator} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <span className="text-xs font-bold flex items-center gap-1.5">
                        <Plus className="h-4 w-4 text-[#22C55E]" />
                        Onboard New Creator
                      </span>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Name *</label>
                          <input
                            type="text"
                            required
                            value={newCreator.name}
                            onChange={(e) => setNewCreator({ ...newCreator, name: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="Ananya Sharma"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Niche Category *</label>
                          <input
                            type="text"
                            required
                            value={newCreator.niche}
                            onChange={(e) => setNewCreator({ ...newCreator, niche: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Beauty & Skincare"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Followers Count *</label>
                          <input
                            type="text"
                            required
                            value={newCreator.followers}
                            onChange={(e) => setNewCreator({ ...newCreator, followers: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. 350K+"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Engagement %</label>
                          <input
                            type="text"
                            value={newCreator.engagement}
                            onChange={(e) => setNewCreator({ ...newCreator, engagement: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. 7.5%"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Recent Brands</label>
                          <input
                            type="text"
                            value={newCreator.recentBrand}
                            onChange={(e) => setNewCreator({ ...newCreator, recentBrand: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Nykaa, Plum"
                          />
                        </div>
                      </div>

                      <div className="space-y-2 border border-slate-800/10 dark:border-slate-800/60 p-4.5 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Profile Picture *</label>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          {newCreator.image ? (
                            <img
                              src={newCreator.image}
                              alt="Preview"
                              className="w-14 h-14 rounded-full object-cover border border-[#22C55E]/40"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-14 h-14 rounded-full bg-[#22C55E]/10 border border-dashed border-[#22C55E]/40 flex items-center justify-center text-[#22C55E] text-xs font-bold font-mono">
                              No Pic
                            </div>
                          )}
                          <div className="flex-1 w-full space-y-1.5">
                            <label className={`w-full flex flex-col items-center justify-center px-4 py-3 border border-dashed rounded-xl cursor-pointer transition-all text-center ${
                              darkMode 
                                ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900 hover:border-[#22C55E]/60' 
                                : 'border-slate-300 bg-white hover:bg-slate-100 hover:border-[#22C55E]/60'
                            }`}>
                              <span className="text-xs font-bold text-[#22C55E]">📷 Upload Profile Picture</span>
                              <span className={`text-[9px] mt-0.5 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>PNG, JPG, WEBP up to 2MB</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => handleImageUpload(e, (base64) => setNewCreator({ ...newCreator, image: base64 }))}
                              />
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Username (without @) *</label>
                          <input
                            type="text"
                            required
                            value={newCreator.instagramUsername || ''}
                            onChange={(e) => setNewCreator({ ...newCreator, instagramUsername: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="ananya_sharma"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Profile Link / URL *</label>
                          <input
                            type="url"
                            required
                            value={newCreator.instagramUrl || ''}
                            onChange={(e) => setNewCreator({ ...newCreator, instagramUrl: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. https://www.instagram.com/ananya_sharma"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">City / Location *</label>
                          <input
                            type="text"
                            required
                            value={newCreator.city || ''}
                            onChange={(e) => setNewCreator({ ...newCreator, city: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. Mumbai"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Media Kit / Download URL</label>
                          <input
                            type="text"
                            value={newCreator.mediaKitUrl || ''}
                            onChange={(e) => setNewCreator({ ...newCreator, mediaKitUrl: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. https://drive.google.com/..."
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Languages (comma-separated) *</label>
                          <input
                            type="text"
                            required
                            value={(newCreator.languages || []).join(', ')}
                            onChange={(e) => setNewCreator({ ...newCreator, languages: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="e.g. English, Hindi"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Contact Information / Private Notes</label>
                          <input
                            type="text"
                            value={newCreator.contactInfo || ''}
                            onChange={(e) => setNewCreator({ ...newCreator, contactInfo: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                            }`}
                            placeholder="Email, Phone, or Manager contact details"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Short Biography / Bio *</label>
                        <textarea
                          rows={3}
                          required
                          value={newCreator.bio || ''}
                          onChange={(e) => setNewCreator({ ...newCreator, bio: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${
                            darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                          }`}
                          placeholder="Tell us about their style, key demographics, and audience vibe..."
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Platforms</label>
                        <div className="flex items-center gap-4 pt-1">
                          {['Instagram', 'YouTube', 'Threads', 'Pinterest'].map(p => {
                            const hasPlat = (newCreator.platforms || []).includes(p);
                            return (
                              <label key={p} className="flex items-center gap-1.5 text-xs cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={hasPlat}
                                  onChange={(e) => {
                                    const current = newCreator.platforms || [];
                                    if (e.target.checked) {
                                      setNewCreator({
                                        ...newCreator,
                                        platforms: [...current, p]
                                      });
                                    } else {
                                      setNewCreator({
                                        ...newCreator,
                                        platforms: current.filter(plat => plat !== p)
                                      });
                                    }
                                  }}
                                  className="accent-[#22C55E]"
                                />
                                <span>{p}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 cursor-pointer"
                      >
                        Onboard Creator
                      </button>
                    </form>
                  )}

                  {/* Creator Registry Directory list */}
                  <div className="space-y-3">
                    {/* Clear all preloaded creators option */}
                    <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                      darkMode ? 'bg-red-950/10 border-red-900/30' : 'bg-red-50/50 border-red-150'
                    }`}>
                      <div className="text-left space-y-0.5">
                        <h5 className="text-xs font-bold text-red-500">Curate Only Your Added Influencers</h5>
                        <p className={`text-[10px] leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          Wipe all preloaded default creators so you can have a fully fresh clean slate and show <strong>only</strong> your manually added creators!
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm('Are you sure you want to remove ALL preloaded creators? This lets you start fresh to show ONLY influencers you add yourself.')) {
                            setCreators([]);
                          }
                        }}
                        className="px-3.5 py-2 bg-red-500 hover:bg-red-600 active:scale-95 text-white rounded-xl text-xs font-bold tracking-tight transition-all shrink-0 cursor-pointer"
                      >
                        Wipe Default Creators
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Registry Directory ({creators.length})</h4>
                    </div>
                    <div className="space-y-2">
                      {creators.map(creator => (
                        <div key={creator.id} className={`p-4 rounded-xl border flex items-center justify-between ${
                          darkMode ? 'bg-slate-950/40 border-slate-850 hover:bg-slate-900' : 'bg-white border-slate-150 hover:bg-slate-50 shadow-xs'
                        }`}>
                          <div className="flex items-center gap-3">
                            <img src={creator.image} alt={creator.name} className="w-10 h-10 rounded-full object-cover shrink-0 border" />
                            <div className="text-left">
                              <h5 className="text-xs font-bold">{creator.name}</h5>
                              <p className={`text-[10px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                                {creator.niche} • <span className="text-[#22C55E] font-semibold">{creator.followers}</span> Followers ({creator.engagement} ER)
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => {
                                setEditingCreator(creator);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              className={`p-1.5 rounded-lg border text-xs transition-all ${
                                darkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                              }`}
                              title="Edit Creator"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteCreator(creator.id)}
                              className={`p-1.5 rounded-lg border text-xs transition-all text-red-500 ${
                                darkMode ? 'border-slate-800 hover:bg-red-500/10' : 'border-slate-200 hover:bg-red-50'
                              }`}
                              title="Delete Creator"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Services Copy */}
              {activeTab === 'services' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-extrabold font-display">Services Directory</h3>
                    <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Edit copy, highlights, and features for the campaign categories shown on the main page.
                    </p>
                  </div>

                  {editingService ? (
                    <form onSubmit={handleUpdateService} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className="flex items-center justify-between border-b pb-2 border-slate-800/40">
                        <span className="text-xs font-bold text-[#22C55E]">Editing Service: {editingService.title}</span>
                        <button type="button" onClick={() => setEditingService(null)} className="text-[10px] text-slate-500">Cancel</button>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Title</label>
                          <input
                            type="text"
                            required
                            value={editingService.title}
                            onChange={(e) => setEditingService({ ...editingService, title: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Badge/Highlight</label>
                          <input
                            type="text"
                            value={editingService.badge || ''}
                            onChange={(e) => setEditingService({ ...editingService, badge: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Popular, High Impact"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Description</label>
                        <textarea
                          required
                          rows={3}
                          value={editingService.description}
                          onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Bullet Features (one per line)</label>
                        <textarea
                          required
                          rows={3}
                          value={editingService.features.join('\n')}
                          onChange={(e) => setEditingService({ ...editingService, features: e.target.value.split('\n') })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border font-mono ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 flex items-center gap-1 cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Save Service Copy
                      </button>
                    </form>
                  ) : (
                    <div className="space-y-3">
                      {services.map(service => (
                        <div key={service.id} className={`p-4 rounded-xl border flex items-center justify-between ${
                          darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-white border-slate-150 shadow-xs'
                        }`}>
                          <div className="text-left space-y-1">
                            <div className="flex items-center gap-2">
                              <h5 className="text-xs font-extrabold">{service.title}</h5>
                              {service.badge && (
                                <span className="text-[8px] px-2 py-0.5 rounded-full bg-[#22C55E]/10 text-[#22C55E] uppercase font-mono font-bold">
                                  {service.badge}
                                </span>
                              )}
                            </div>
                            <p className={`text-[10px] leading-relaxed max-w-xl ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                              {service.description}
                            </p>
                          </div>
                          
                          <button
                            onClick={() => setEditingService(service)}
                            className={`p-1.5 rounded-lg border text-xs transition-all ${
                              darkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                            }`}
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Testimonials Registry */}
              {activeTab === 'testimonials' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-extrabold font-display">Testimonials Directory</h3>
                    <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Manage founder success stories and recommendations displayed on the home page.
                    </p>
                  </div>

                  {editingTestimonial ? (
                    <form onSubmit={handleUpdateTestimonial} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className="flex items-center justify-between border-b pb-2 border-slate-800/40">
                        <span className="text-xs font-bold text-[#22C55E]">Editing Testimonial</span>
                        <button type="button" onClick={() => setEditingTestimonial(null)} className="text-[10px] text-slate-500">Cancel</button>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Reviewer Name</label>
                          <input
                            type="text"
                            required
                            value={editingTestimonial.name}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, name: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Role / Designation</label>
                          <input
                            type="text"
                            required
                            value={editingTestimonial.role}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, role: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="e.g. Founder"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Company Name</label>
                          <input
                            type="text"
                            required
                            value={editingTestimonial.company}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, company: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Niche Category</label>
                          <input
                            type="text"
                            required
                            value={editingTestimonial.niche}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, niche: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Rating Stars (1-5)</label>
                          <input
                            type="number"
                            min="1"
                            max="5"
                            required
                            value={editingTestimonial.rating}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, rating: parseInt(e.target.value) || 5 })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                      </div>

                      <div className="space-y-2 border border-slate-800/10 dark:border-slate-800/60 p-4.5 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Avatar Picture</label>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          {editingTestimonial.avatar ? (
                            <img
                              src={editingTestimonial.avatar}
                              alt="Preview"
                              className="w-12 h-12 rounded-full object-cover border border-[#22C55E]/40"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-[#22C55E]/10 border border-dashed border-[#22C55E]/40 flex items-center justify-center text-[#22C55E] text-xs font-bold font-mono">
                              No Pic
                            </div>
                          )}
                          <div className="flex-1 w-full space-y-1.5">
                            <label className={`w-full flex flex-col items-center justify-center px-4 py-2.5 border border-dashed rounded-xl cursor-pointer transition-all text-center ${
                              darkMode 
                                ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900 hover:border-[#22C55E]/60' 
                                : 'border-slate-300 bg-white hover:bg-slate-100 hover:border-[#22C55E]/60'
                            }`}>
                              <span className="text-xs font-bold text-[#22C55E]">📷 Upload Avatar File</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => handleImageUpload(e, (base64) => setEditingTestimonial({ ...editingTestimonial, avatar: base64 }))}
                              />
                            </label>
                          </div>
                        </div>
                        <div className="pt-2">
                          <label className="text-[9px] font-semibold text-slate-400 block mb-1">Or paste direct Avatar URL:</label>
                          <input
                            type="text"
                            value={editingTestimonial.avatar || ''}
                            onChange={(e) => setEditingTestimonial({ ...editingTestimonial, avatar: e.target.value })}
                            className={`w-full px-3 py-1.5 rounded-xl text-[11px] border focus:outline-none ${
                              darkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
                            }`}
                            placeholder="https://images.unsplash.com/..."
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Review Quote Content</label>
                        <textarea
                          required
                          rows={3}
                          value={editingTestimonial.content}
                          onChange={(e) => setEditingTestimonial({ ...editingTestimonial, content: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 flex items-center gap-1 cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Update Testimonial
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleAddTestimonial} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <span className="text-xs font-bold flex items-center gap-1.5">
                        <Plus className="h-4 w-4 text-[#22C55E]" />
                        Publish Success Story
                      </span>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Founder/Marketer Name *</label>
                          <input
                            type="text"
                            required
                            value={newTestimonial.name}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, name: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="Simran Juneja"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Role *</label>
                          <input
                            type="text"
                            required
                            value={newTestimonial.role}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, role: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="Founder / Head of Growth"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Company Name *</label>
                          <input
                            type="text"
                            required
                            value={newTestimonial.company}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, company: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="Nexa Organics"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Niche Tag</label>
                          <input
                            type="text"
                            value={newTestimonial.niche}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, niche: e.target.value })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                            placeholder="Beauty"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Rating Stars (1-5)</label>
                          <input
                            type="number"
                            min="1"
                            max="5"
                            value={newTestimonial.rating}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, rating: parseInt(e.target.value) || 5 })}
                            className={`w-full px-3 py-2 rounded-xl text-xs border ${
                              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                            }`}
                          />
                        </div>
                      </div>

                      <div className="space-y-2 border border-slate-800/10 dark:border-slate-800/60 p-4.5 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Avatar Picture</label>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          {newTestimonial.avatar ? (
                            <img
                              src={newTestimonial.avatar}
                              alt="Preview"
                              className="w-12 h-12 rounded-full object-cover border border-[#22C55E]/40"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-[#22C55E]/10 border border-dashed border-[#22C55E]/40 flex items-center justify-center text-[#22C55E] text-xs font-bold font-mono">
                              No Pic
                            </div>
                          )}
                          <div className="flex-1 w-full space-y-1.5">
                            <label className={`w-full flex flex-col items-center justify-center px-4 py-2.5 border border-dashed rounded-xl cursor-pointer transition-all text-center ${
                              darkMode 
                                ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900 hover:border-[#22C55E]/60' 
                                : 'border-slate-300 bg-white hover:bg-slate-100 hover:border-[#22C55E]/60'
                            }`}>
                              <span className="text-xs font-bold text-[#22C55E]">📷 Upload Avatar File</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => handleImageUpload(e, (base64) => setNewTestimonial({ ...newTestimonial, avatar: base64 }))}
                              />
                            </label>
                          </div>
                        </div>
                        <div className="pt-2">
                          <label className="text-[9px] font-semibold text-slate-400 block mb-1">Or paste direct Avatar URL:</label>
                          <input
                            type="text"
                            value={newTestimonial.avatar || ''}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, avatar: e.target.value })}
                            className={`w-full px-3 py-1.5 rounded-xl text-[11px] border focus:outline-none ${
                              darkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
                            }`}
                            placeholder="https://images.unsplash.com/..."
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Review quote content *</label>
                        <textarea
                          required
                          rows={2}
                          value={newTestimonial.content}
                          onChange={(e) => setNewTestimonial({ ...newTestimonial, content: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                          placeholder="BillionEra transformed our D2C launch..."
                        />
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 cursor-pointer"
                      >
                        Publish Testimonial
                      </button>
                    </form>
                  )}

                  {/* Testimonial listings */}
                  <div className="space-y-2">
                    {testimonials.map(item => (
                      <div key={item.id} className={`p-4 rounded-xl border flex items-center justify-between ${
                        darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-white border-slate-150 shadow-xs'
                      }`}>
                        <div className="text-left space-y-1">
                          <h5 className="text-xs font-extrabold">{item.name} • <span className="text-[#22C55E]">{item.company}</span></h5>
                          <p className={`text-[10px] line-clamp-2 leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                            "{item.content}"
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-1.5 ml-4 shrink-0">
                          <button
                            onClick={() => setEditingTestimonial(item)}
                            className={`p-1.5 rounded-lg border text-xs transition-all ${
                              darkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                            }`}
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteTestimonial(item.id)}
                            className={`p-1.5 rounded-lg border text-xs text-red-500 transition-all ${
                              darkMode ? 'border-slate-800 hover:bg-red-500/10' : 'border-slate-200 hover:bg-red-50'
                            }`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 4: FAQs Registry */}
              {activeTab === 'faqs' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-extrabold font-display">FAQs Registry</h3>
                    <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Edit questions and clear transparent answers displayed in the accordion panel.
                    </p>
                  </div>

                  {editingFaq ? (
                    <form onSubmit={handleUpdateFaq} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className="flex items-center justify-between border-b pb-2 border-slate-800/40">
                        <span className="text-xs font-bold text-[#22C55E]">Editing FAQ</span>
                        <button type="button" onClick={() => setEditingFaq(null)} className="text-[10px] text-slate-500">Cancel</button>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Question</label>
                        <input
                          type="text"
                          required
                          value={editingFaq.question}
                          onChange={(e) => setEditingFaq({ ...editingFaq, question: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Answer</label>
                        <textarea
                          required
                          rows={4}
                          value={editingFaq.answer}
                          onChange={(e) => setEditingFaq({ ...editingFaq, answer: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 flex items-center gap-1 cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Update FAQ
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleAddFaq} className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <span className="text-xs font-bold flex items-center gap-1.5">
                        <Plus className="h-4 w-4 text-[#22C55E]" />
                        Add New FAQ Question
                      </span>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Question *</label>
                        <input
                          type="text"
                          required
                          value={newFaq.question}
                          onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                          placeholder="e.g. How does BillionEra select creators?"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Answer *</label>
                        <textarea
                          required
                          rows={3}
                          value={newFaq.answer}
                          onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                          placeholder="We perform dynamic manual quality checks..."
                        />
                      </div>

                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#22C55E] text-slate-950 rounded-lg text-xs font-bold hover:bg-emerald-500 cursor-pointer"
                      >
                        Publish FAQ
                      </button>
                    </form>
                  )}

                  {/* FAQ Directory listings */}
                  <div className="space-y-2">
                    {faqs.map(faq => (
                      <div key={faq.id} className={`p-4 rounded-xl border flex items-center justify-between ${
                        darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-white border-slate-150 shadow-xs'
                      }`}>
                        <div className="text-left space-y-1">
                          <h5 className="text-xs font-extrabold">{faq.question}</h5>
                          <p className={`text-[10px] line-clamp-1 leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                            {faq.answer}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-1.5 ml-4 shrink-0">
                          <button
                            onClick={() => setEditingFaq(faq)}
                            className={`p-1.5 rounded-lg border text-xs transition-all ${
                              darkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                            }`}
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteFaq(faq.id)}
                            className={`p-1.5 rounded-lg border text-xs text-red-500 transition-all ${
                              darkMode ? 'border-slate-800 hover:bg-red-500/10' : 'border-slate-200 hover:bg-red-50'
                            }`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 5: Site Settings */}
              {activeTab === 'settings' && (
                <form onSubmit={handleSaveSettings} className="space-y-6 text-left">
                  <div>
                    <h3 className="text-base font-extrabold font-display">Global Copywriting Settings</h3>
                    <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>
                      Instantly change the main texts, hero tagline, badges, and agency emails/WhatsApp details shown on the website.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Hero Floating Badge</label>
                        <input
                          type="text"
                          required
                          value={settingsForm.heroBadge}
                          onChange={(e) => setSettingsForm({ ...settingsForm, heroBadge: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Support Email Address</label>
                        <input
                          type="email"
                          required
                          value={settingsForm.contactEmail}
                          onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Support WhatsApp Number (e.g. +91 ...)</label>
                        <input
                          type="text"
                          required
                          value={settingsForm.contactPhone}
                          onChange={(e) => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Instagram Profile Link</label>
                        <input
                          type="text"
                          required
                          value={settingsForm.contactInstagram}
                          onChange={(e) => setSettingsForm({ ...settingsForm, contactInstagram: e.target.value })}
                          className={`w-full px-3 py-2 rounded-xl text-xs border ${
                            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Hero Main Title</label>
                      <input
                        type="text"
                        required
                        value={settingsForm.heroTitle}
                        onChange={(e) => setSettingsForm({ ...settingsForm, heroTitle: e.target.value })}
                        className={`w-full px-3 py-2 rounded-xl text-xs border ${
                          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                        }`}
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Hero Subtext Description</label>
                      <textarea
                        required
                        rows={4}
                        value={settingsForm.heroDescription}
                        onChange={(e) => setSettingsForm({ ...settingsForm, heroDescription: e.target.value })}
                        className={`w-full px-3 py-2 rounded-xl text-xs border resize-none ${
                          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
                        }`}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#22C55E] text-slate-950 font-bold rounded-xl text-xs hover:bg-emerald-500 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Save className="h-4 w-4" />
                    <span>Save Site Copywriting</span>
                  </button>
                </form>
              )}

              {/* Tab 6: Copy-Paste Hub */}
              {activeTab === 'copy-paste' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-extrabold font-display">Copy-Paste Hub</h3>
                    <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Access and customize professional copywriting materials. Edit them right here and copy them with one click!
                    </p>
                  </div>

                  <div className="space-y-6">
                    {[
                      {
                        title: '⚡ Instagram / WA Creator Outreach Pitch',
                        desc: 'Copy-paste customizable outreach pitch to potential creators.',
                        template: `Hey [Creator Name]! 🌟\n\nI love your content, especially your recent reel about [Topic]! Your style is a perfect fit for BillionEra's brand network.\n\nWe are launching an exciting new campaign for a premium D2C brand in the [Niche] space and would love to onboard you.\n\nDeliverables:\n- 1 Dedicated Instagram Reel\n- 2 Story slides with swipe-up/sticker link\n\nWould you be open to collaborating? Let me know your commercial rates or if we can hop on a quick 5-min WhatsApp call! \n\nBest,\n[Your Name]\nBillionEra Creator Network`
                      },
                      {
                        title: '🤝 Brand Partnership Pitch Proposal',
                        desc: 'Pitch your influencer network and execution capabilities to D2C startup heads.',
                        template: `Subject: Scale [Brand Name] through verified high-ROI creators 🚀\n\nHi [Founder Name],\n\nI am [Your Name], Founder at BillionEra. I have been following [Brand Name] and love your product positioning.\n\nWe help leading D2C brands scale in India through curated micro-influencers with high-engagement rates. Our network covers Fashion, Beauty, Food, and Lifestyle.\n\nWhy brands choose BillionEra:\n- 100% verified engagement rates (no bot followers)\n- End-to-end campaign execution & brief coordination\n- Performance reports & high-conversion content hooks\n\nI have prepared a custom list of 5 creators who fit [Brand Name] perfectly. Would you have 10 minutes next Tuesday at 3 PM for a quick chat?\n\nBest regards,\n[Your Name]\nBillionEra Network\nWhatsApp: [Your Phone]`
                      },
                      {
                        title: '📝 Campaign Brief & Creator Guidelines',
                        desc: 'Standard professional campaign outline to keep content high quality.',
                        template: `CAMPAIGN BRIEF & OUTLINE\n\n1. Brand Partner: [Brand Name]\n2. Product Focus: [Product Highlight]\n3. Core Angle: Highlight authentic daily usage. Showcase before/after or quick lookbook styling.\n4. Deliverables: 1 Reel (within 30-45 seconds) + 1 Story slide.\n5. Key Tags: @[BrandHandle] #BillionEraCreators #Ad\n\nDOs:\n- Start with a strong 3-second hook (e.g. "This product single-handedly fixed my...")\n- Natural lighting and crystal clear audio.\n- Focus on texture, look, and authentic emotional response.\n\nDONTs:\n- Avoid overly scripted corporate language.\n- Do not mention competitor brands.\n\nDraft submission date: [Date]\nLive post date: [Date]`
                      }
                    ].map((item, idx) => (
                      <TemplateBlock key={idx} item={item} darkMode={darkMode} />
                    ))}
                  </div>
                </div>
              )}

            </div>

          </div>
        )}

      </div>
    </div>
  );
}

interface TemplateBlockProps {
  key?: any;
  item: {
    title: string;
    desc: string;
    template: string;
  };
  darkMode: boolean;
}

function TemplateBlock({ item, darkMode }: TemplateBlockProps) {
  const [text, setText] = useState(item.template);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`p-6 rounded-2xl border text-left space-y-3.5 transition-all ${
      darkMode ? 'bg-slate-950/20 border-slate-800 hover:border-slate-700/60' : 'bg-slate-50 border-slate-200 hover:border-slate-300 shadow-sm'
    }`}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-2.5 border-slate-800/20 dark:border-slate-700/20">
        <div>
          <h4 className="text-xs font-bold text-[#22C55E] uppercase tracking-wider">{item.title}</h4>
          <p className={`text-[10px] mt-0.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>{item.desc}</p>
        </div>
        <button
          onClick={handleCopy}
          className={`px-3.5 py-1.5 rounded-xl text-[10px] font-bold transition-all flex items-center gap-1.5 shrink-0 self-start sm:self-center cursor-pointer ${
            copied 
              ? 'bg-[#22C55E] text-slate-950 shadow-md shadow-[#22C55E]/15' 
              : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
          }`}
        >
          {copied ? (
            <>
              <Check className="h-3 w-3" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="h-3 w-3" />
              <span>Copy Template</span>
            </>
          )}
        </button>
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={7}
        className={`w-full p-3 rounded-xl text-xs border font-mono leading-relaxed focus:outline-none focus:ring-1 focus:ring-[#22C55E]/40 ${
          darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800 shadow-inner'
        }`}
      />
    </div>
  );
}
