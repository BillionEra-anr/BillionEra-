import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, ArrowUpRight } from 'lucide-react';

interface HeroProps {
  darkMode: boolean;
  onNavigate: (sectionId: string) => void;
  siteSettings: {
    heroBadge: string;
    heroTitle: string;
    heroDescription: string;
  };
}

export default function Hero({ darkMode, onNavigate, siteSettings }: HeroProps) {
  const renderTitle = (title: string) => {
    if (!title) return '';
    const words = title.split(' ');
    if (words.length <= 1) {
      return <span className="text-[#22C55E]">{title}</span>;
    }
    const lastWord = words[words.length - 1];
    const firstPart = words.slice(0, words.length - 1).join(' ');
    return (
      <>
        {firstPart}{' '}
        <span className="relative inline-block text-[#22C55E]">
          {lastWord}
          <span className="absolute bottom-1.5 left-0 w-full h-[6px] bg-[#22C55E]/20 rounded-full" />
        </span>
      </>
    );
  };

  return (
    <section
      id="hero"
      className={`relative pt-28 pb-6 md:pb-8 overflow-hidden transition-colors duration-300 ${
        darkMode ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Background Gradients */}
      <div className="absolute inset-0 pointer-events-none">
        <div className={`absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full filter blur-[140px] opacity-40 transition-colors ${
          darkMode ? 'bg-[#22C55E]/10' : 'bg-[#22C55E]/5'
        }`} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto space-y-8">
          
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-green-50 dark:bg-[#22C55E]/10 text-[#22C55E] border border-green-200/20 dark:border-transparent rounded-full text-xs font-bold uppercase tracking-tighter"
          >
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
            <span>{siteSettings.heroBadge}</span>
          </motion.div>

          <div className="space-y-4">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-7xl font-display font-extrabold tracking-tight leading-[1.1]"
            >
              {renderTitle(siteSettings.heroTitle)}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className={`text-base sm:text-lg lg:text-xl font-normal leading-relaxed max-w-2xl mx-auto ${
                darkMode ? 'text-slate-300' : 'text-slate-500'
              }`}
            >
              {siteSettings.heroDescription}
            </motion.p>
          </div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 pt-2 justify-center w-full sm:w-auto"
          >
            <button
              onClick={() => onNavigate('creators')}
              className="px-8 py-4 rounded-xl text-lg font-bold bg-[#22C55E] text-white hover:bg-emerald-600 active:scale-[0.98] transition-all shadow-lg shadow-green-200 dark:shadow-green-900/10 flex items-center justify-center cursor-pointer group"
            >
              Browse Creators
              <ArrowUpRight className="h-4 w-4 ml-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </button>
            
            <a
              href="https://wa.me/919576751269?text=Hi%20BillionEra,%20I'm%20interested%20in%20starting%20an%20influencer%20campaign%20for%20my%20brand."
              target="_blank"
              rel="noopener noreferrer"
              className={`px-8 py-4 rounded-xl text-lg font-bold border-2 active:scale-[0.98] transition-all flex items-center justify-center cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 hover:bg-slate-800 hover:border-slate-700 text-slate-100'
                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
              }`}
            >
              <MessageSquare className="h-5 w-5 mr-2 text-[#22C55E]" />
              Contact on WhatsApp
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
