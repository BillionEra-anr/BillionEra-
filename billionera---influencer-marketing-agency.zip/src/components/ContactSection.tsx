import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, MessageSquare, Instagram, Copy, Check, Send, Sparkles, AlertCircle, Phone } from 'lucide-react';

interface ContactSectionProps {
  darkMode: boolean;
  siteSettings: {
    contactEmail: string;
    contactPhone: string;
    contactInstagram: string;
  };
}

interface FormState {
  fullName: string;
  email: string;
  brandName: string;
  category: string;
  budget: number;
  message: string;
}

export default function ContactSection({ darkMode, siteSettings }: ContactSectionProps) {
  const getWhatsAppNumber = (phone: string) => {
    return phone.replace(/[^\d]/g, '');
  };
  const getInstagramHandle = (url: string) => {
    try {
      const parts = url.replace(/\/$/, '').split('/');
      const lastPart = parts[parts.length - 1];
      const name = lastPart.includes('?') ? lastPart.split('?')[0] : lastPart;
      return name.startsWith('@') ? name : `@${name}`;
    } catch (e) {
      return '@billionera';
    }
  };

  const [form, setForm] = useState<FormState>({
    fullName: '',
    email: '',
    brandName: '',
    category: 'Fashion',
    budget: 50000,
    message: ''
  });

  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Partial<FormState>>({});

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, budget: parseInt(e.target.value) });
  };

  // Live Metric Calculator based on budget
  const getEstimatedCreators = (budget: number) => {
    if (budget < 25000) return { reach: '100K - 250K', creators: '2-4 Creators' };
    if (budget < 75000) return { reach: '300K - 600K', creators: '4-7 Creators' };
    if (budget < 150000) return { reach: '700K - 1.2M', creators: '8-12 Creators' };
    return { reach: '1.5M - 3M+', creators: '15+ Custom Mix' };
  };

  const validate = (): boolean => {
    const tempErrors: Partial<FormState> = {};
    if (!form.fullName.trim()) tempErrors.fullName = 'Full name is required';
    if (!form.email.trim()) {
      tempErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      tempErrors.email = 'Email address is invalid';
    }
    if (!form.brandName.trim()) tempErrors.brandName = 'Brand/Company name is required';
    if (!form.message.trim()) tempErrors.message = 'Please share some details about your campaign';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
    }, 1500);
  };

  const { reach, creators } = getEstimatedCreators(form.budget);

  return (
    <section
      id="contact"
      className={`py-12 md:py-16 transition-colors duration-300 relative ${
        darkMode ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Background radial gradient */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#22C55E]/5 filter blur-[140px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-green-50 dark:bg-[#22C55E]/10 text-[#22C55E] border border-green-200/20 dark:border-transparent rounded-full text-xs font-bold uppercase tracking-tighter">
            <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
            Get In Touch
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold tracking-tight">
            Launch Your Next Campaign
          </h2>
          <p className={`text-base leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>
            Fill out the brief consultation details below. Our strategy team will review your requirements and coordinate a tailored list of matching creators.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Contacts */}
          <div className="lg:col-span-5 space-y-8">
            <div className={`p-8 rounded-3xl border ${
              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm shadow-slate-100'
            }`}>
              <h3 className="text-xl font-display font-bold mb-6">Contact Channels</h3>
              
              <div className="space-y-4">
                {/* Email Card */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-[#22C55E]/10 text-[#22C55E]">
                      <Mail className="h-5 w-5" />
                    </div>
                    <div>
                      <p className={`text-[10px] font-mono uppercase tracking-wider ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>Email Us</p>
                      <a href={`mailto:${siteSettings.contactEmail}`} className="text-sm font-semibold hover:text-[#22C55E] transition-colors">
                        {siteSettings.contactEmail}
                      </a>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(siteSettings.contactEmail, 'email')}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      darkMode ? 'border-slate-800 hover:bg-slate-850 text-slate-400' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                    }`}
                    title="Copy Email Address"
                  >
                    {copiedText === 'email' ? <Check className="h-4 w-4 text-[#22C55E]" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>

                {/* WhatsApp Card */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-emerald-500/15 text-emerald-500">
                      <Phone className="h-5 w-5" />
                    </div>
                    <div>
                      <p className={`text-[10px] font-mono uppercase tracking-wider ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>WhatsApp Chat</p>
                      <a href={`https://wa.me/${getWhatsAppNumber(siteSettings.contactPhone)}`} target="_blank" rel="noopener noreferrer" className="text-sm font-semibold hover:text-emerald-500 transition-colors">
                        {siteSettings.contactPhone}
                      </a>
                    </div>
                  </div>
                  <a
                    href={`https://wa.me/${getWhatsAppNumber(siteSettings.contactPhone)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 transition-colors flex items-center justify-center text-xs font-semibold gap-1.5 shadow-sm"
                  >
                    <MessageSquare className="h-4 w-4" />
                    Chat
                  </a>
                </div>

                {/* Instagram Card */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-pink-500/15 text-pink-500">
                      <Instagram className="h-5 w-5" />
                    </div>
                    <div>
                      <p className={`text-[10px] font-mono uppercase tracking-wider ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>Instagram Handle</p>
                      <a href={siteSettings.contactInstagram} target="_blank" rel="noopener noreferrer" className="text-sm font-semibold hover:text-pink-500 transition-colors">
                        {getInstagramHandle(siteSettings.contactInstagram)}
                      </a>
                    </div>
                  </div>
                  <a
                    href={siteSettings.contactInstagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg border border-pink-500/20 text-pink-500 hover:bg-pink-500/10 transition-colors"
                  >
                    Follow
                  </a>
                </div>
              </div>
            </div>

            {/* Campaign Metrics Calculator Side-Card */}
            <div className={`p-8 rounded-3xl border relative overflow-hidden ${
              darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm shadow-slate-100'
            }`}>
              <span className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-[#22C55E]/5 filter blur-xl" />
              
              <h3 className="text-lg font-display font-bold flex items-center gap-2 mb-4">
                <Sparkles className="h-4 w-4 text-[#22C55E]" />
                Live Campaign Estimator
              </h3>
              
              <p className={`text-xs mb-6 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Slide the budget selector to estimate your brand's reach and ideal creator volume through the BillionEra network.
              </p>

              <div className="space-y-5">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-2">
                    <span className={darkMode ? 'text-slate-400' : 'text-slate-500'}>Campaign Budget:</span>
                    <span className="font-bold text-[#22C55E]">₹{form.budget.toLocaleString('en-IN')}</span>
                  </div>
                  <input
                    type="range"
                    min="15000"
                    max="200000"
                    step="5000"
                    value={form.budget}
                    onChange={handleSliderChange}
                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#22C55E]"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                    <span>₹15K</span>
                    <span>₹100K</span>
                    <span>₹200K+</span>
                  </div>
                </div>

                <div className={`p-4 rounded-xl space-y-3 ${
                  darkMode ? 'bg-slate-950/50' : 'bg-slate-50'
                }`}>
                  <div className="flex justify-between text-xs">
                    <span className={darkMode ? 'text-slate-400' : 'text-slate-500'}>Estimated Creators:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{creators}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className={darkMode ? 'text-slate-400' : 'text-slate-500'}>Est. Impression Reach:</span>
                    <span className="font-bold text-[#22C55E]">{reach}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {!success ? (
                <motion.div
                  key="form-container"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className={`p-8 sm:p-10 rounded-3xl border ${
                    darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'
                  }`}
                >
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {/* Name */}
                      <div className="space-y-1.5">
                        <label className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          Full Name *
                        </label>
                        <input
                          type="text"
                          value={form.fullName}
                          onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] focus:border-[#22C55E] ${
                            errors.fullName
                              ? 'border-red-500 bg-red-500/5'
                              : darkMode
                                ? 'bg-slate-950 border-slate-850 text-white'
                                : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                          placeholder="Anand Iyer"
                        />
                        {errors.fullName && (
                          <p className="text-[10px] text-red-500 flex items-center gap-1">
                            <AlertCircle className="h-3 w-3" /> {errors.fullName}
                          </p>
                        )}
                      </div>

                      {/* Email */}
                      <div className="space-y-1.5">
                        <label className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          Business Email *
                        </label>
                        <input
                          type="email"
                          value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] focus:border-[#22C55E] ${
                            errors.email
                              ? 'border-red-500 bg-red-500/5'
                              : darkMode
                                ? 'bg-slate-950 border-slate-850 text-white'
                                : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                          placeholder="anand@brand.com"
                        />
                        {errors.email && (
                          <p className="text-[10px] text-red-500 flex items-center gap-1">
                            <AlertCircle className="h-3 w-3" /> {errors.email}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {/* Brand Name */}
                      <div className="space-y-1.5">
                        <label className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          Brand Name / Website *
                        </label>
                        <input
                          type="text"
                          value={form.brandName}
                          onChange={(e) => setForm({ ...form, brandName: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] focus:border-[#22C55E] ${
                            errors.brandName
                              ? 'border-red-500 bg-red-500/5'
                              : darkMode
                                ? 'bg-slate-950 border-slate-850 text-white'
                                : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                          placeholder="Nexa Organics"
                        />
                        {errors.brandName && (
                          <p className="text-[10px] text-red-500 flex items-center gap-1">
                            <AlertCircle className="h-3 w-3" /> {errors.brandName}
                          </p>
                        )}
                      </div>

                      {/* Category Selection */}
                      <div className="space-y-1.5">
                        <label className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          Niche Interest
                        </label>
                        <select
                          value={form.category}
                          onChange={(e) => setForm({ ...form, category: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] focus:border-[#22C55E] ${
                            darkMode
                              ? 'bg-slate-950 border-slate-850 text-white'
                              : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        >
                          <option value="Fashion">Fashion</option>
                          <option value="Lifestyle">Lifestyle</option>
                          <option value="Food">Food</option>
                          <option value="Beauty">Beauty</option>
                        </select>
                      </div>
                    </div>

                    {/* Message */}
                    <div className="space-y-1.5">
                      <label className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                        Share Your Campaign Objectives *
                      </label>
                      <textarea
                        value={form.message}
                        onChange={(e) => setForm({ ...form, message: e.target.value })}
                        rows={4}
                        className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-1 focus:ring-[#22C55E] focus:border-[#22C55E] resize-none ${
                          errors.message
                            ? 'border-red-500 bg-red-500/5'
                            : darkMode
                              ? 'bg-slate-950 border-slate-850 text-white'
                              : 'bg-slate-50 border-slate-200 text-slate-900'
                        }`}
                        placeholder="Explain your goals, e.g., 'We want to launch our summer activewear collection using 8 aesthetic lifestyle creators across Bangalore and Mumbai...'"
                      />
                      {errors.message && (
                        <p className="text-[10px] text-red-500 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" /> {errors.message}
                        </p>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-4 rounded-full text-sm font-bold bg-[#22C55E] text-white hover:bg-emerald-500 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#22C55E]/15"
                    >
                      {submitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-slate-950 border-t-transparent" />
                          <span>Preparing Consultation...</span>
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          <span>Submit Consultation Brief</span>
                        </>
                      )}
                    </button>
                  </form>
                </motion.div>
              ) : (
                <motion.div
                  key="success-container"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className={`p-10 rounded-3xl border text-center space-y-6 ${
                    darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-md'
                  }`}
                >
                  <div className="w-16 h-16 rounded-full bg-[#22C55E]/10 border border-[#22C55E]/20 flex items-center justify-center text-[#22C55E] mx-auto">
                    <Check className="h-8 w-8 stroke-[3]" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-2xl font-display font-bold">Brief Submitted Successfully!</h3>
                    <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Thank you, <span className="font-bold text-[#22C55E]">{form.fullName}</span>. We have registered your campaign brief for <span className="font-semibold">{form.brandName}</span> under the <span className="font-semibold text-[#22C55E]">{form.category}</span> niche.
                    </p>
                  </div>

                  <div className={`p-6 rounded-2xl border text-left space-y-2.5 max-w-md mx-auto text-xs ${
                    darkMode ? 'bg-slate-950 border-slate-850' : 'bg-slate-50 border-slate-150'
                  }`}>
                    <p className="font-semibold text-[#22C55E] uppercase tracking-wider text-[10px] font-mono">Next Steps:</p>
                    <p className="leading-relaxed text-slate-700 dark:text-slate-300">1. We will audit your brand presence and competitor layouts within 12 hours.</p>
                    <p className="leading-relaxed text-slate-700 dark:text-slate-300">2. Our campaign manager will email you a curated shortlist of 4 creators with customized pricing options.</p>
                    <p className="leading-relaxed text-slate-700 dark:text-slate-300">3. We schedule a free strategy call to lock in content drafts and shipment schedules.</p>
                  </div>

                  <button
                    onClick={() => {
                      setSuccess(false);
                      setForm({
                        fullName: '',
                        email: '',
                        brandName: '',
                        category: 'Fashion',
                        budget: 50000,
                        message: ''
                      });
                    }}
                    className={`px-6 py-2.5 rounded-full text-xs font-bold border transition-all active:scale-95 cursor-pointer ${
                      darkMode ? 'border-slate-850 hover:bg-slate-950 text-slate-300' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    Submit Another Brief
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
