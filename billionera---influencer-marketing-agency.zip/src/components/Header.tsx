import React, { useState, useEffect } from 'react';
import { Menu, X, Rocket, Sparkles, MessageSquare, Shield } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  onNavigate: (sectionId: string) => void;
  onOpenAdmin: () => void;
}

export default function Header({ darkMode, setDarkMode, onNavigate, onOpenAdmin }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Browse Creators', target: 'creators' },
    { label: 'Contact', target: 'contact' },
  ];

  const handleLinkClick = (target: string) => {
    setIsOpen(false);
    onNavigate(target);
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? darkMode
            ? 'bg-slate-950/80 backdrop-blur-md border-b border-slate-800/40 shadow-lg'
            : 'bg-white/80 backdrop-blur-md border-b border-slate-200/50 shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            id="logo-brand" 
            className="flex items-center cursor-pointer group"
            onClick={() => handleLinkClick('hero')}
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-[#22C55E] text-white font-display font-bold text-xl mr-2.5 transition-all group-hover:scale-105 shadow-md shadow-[#22C55E]/20">
              B
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-slate-950 dark:bg-white animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className={`font-display font-bold text-xl tracking-tight leading-none ${
                darkMode ? 'text-white' : 'text-slate-900'
              }`}>
                Billion<span className="text-[#22C55E]">Era</span>
              </span>
              <span className={`text-[9px] font-mono tracking-wider uppercase mt-1 ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                Influencer Marketing
              </span>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav id="desktop-nav" className="hidden md:flex items-center space-x-8 text-xs font-medium uppercase tracking-widest text-slate-600">
            {menuItems.map((item) => (
              <button
                key={item.target}
                onClick={() => handleLinkClick(item.target)}
                className={`transition-colors cursor-pointer ${
                  darkMode ? 'text-slate-300 hover:text-[#22C55E]' : 'text-slate-600 hover:text-[#22C55E]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div id="desktop-actions" className="hidden md:flex items-center space-x-6">
            <button
              onClick={onOpenAdmin}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                darkMode 
                  ? 'border-slate-800 text-slate-400 hover:text-white hover:bg-slate-900' 
                  : 'border-slate-200 text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="Admin Portal"
            >
              <Shield className="h-5 w-5" />
            </button>
            <button
              onClick={() => handleLinkClick('contact')}
              className={`px-6 py-2.5 rounded-full text-sm font-semibold active:scale-95 transition-all shadow-md cursor-pointer ${
                darkMode 
                  ? 'bg-[#22C55E] text-slate-950 hover:bg-emerald-500 shadow-[#22C55E]/10' 
                  : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              Book Free Consultation
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button
              id="mobile-menu-btn"
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 rounded-xl border transition-colors ${
                darkMode 
                  ? 'border-slate-800 text-slate-300 hover:bg-slate-900' 
                  : 'border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      <div
        id="mobile-menu-drawer"
        className={`fixed inset-y-0 right-0 z-40 w-full max-w-xs transform ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        } transition-transform duration-300 ease-in-out md:hidden shadow-2xl border-l ${
          darkMode 
            ? 'bg-slate-950 border-slate-800 text-white' 
            : 'bg-slate-50 border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex flex-col h-full justify-between p-6 pt-24">
          <div className="space-y-6">
            <div className="flex flex-col space-y-4">
              {menuItems.map((item) => (
                <button
                  key={item.target}
                  onClick={() => handleLinkClick(item.target)}
                  className={`text-left font-display text-lg font-semibold transition-colors py-2 border-b ${
                    darkMode 
                      ? 'border-slate-900 text-slate-200 hover:text-[#22C55E]' 
                      : 'border-slate-100 text-slate-800 hover:text-[#22C55E]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4 pb-6">
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenAdmin();
              }}
              className={`w-full flex items-center justify-center px-5 py-3.5 rounded-full text-sm font-semibold border transition-colors ${
                darkMode
                  ? 'border-slate-800 hover:bg-slate-900 text-slate-200'
                  : 'border-slate-200 hover:bg-white text-slate-800'
              }`}
            >
              <Shield className="h-4 w-4 mr-2 text-[#22C55E]" />
              Admin Portal
            </button>
            <button
              onClick={() => handleLinkClick('contact')}
              className="w-full flex items-center justify-center px-5 py-3.5 rounded-full text-sm font-semibold bg-[#22C55E] text-slate-950 hover:bg-emerald-500 transition-colors shadow-lg shadow-[#22C55E]/15"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Book Free Consultation
            </button>
          </div>
        </div>
      </div>

      {/* Backdrop for Mobile Drawer */}
      {isOpen && (
        <div
          id="mobile-backdrop"
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-xs md:hidden"
        />
      )}
    </header>
  );
}
