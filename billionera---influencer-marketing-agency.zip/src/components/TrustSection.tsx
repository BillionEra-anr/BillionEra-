import React from 'react';
import { Users, Sparkles, Sliders, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

interface TrustSectionProps {
  darkMode: boolean;
}

export default function TrustSection({ darkMode }: TrustSectionProps) {
  const trustMetrics = [
    {
      id: 'metric-1',
      icon: <Users className="h-6 w-6" />,
      title: '30+ Verified Creators',
      description: 'Hand-picked elite Indian creators with highly active, genuine followers and verified conversion histories.',
      tag: 'Curation'
    },
    {
      id: 'metric-2',
      icon: <Sparkles className="h-6 w-6" />,
      title: 'Fashion • Lifestyle • Food • Beauty',
      description: 'Expert creators specializing in D2C categories to deliver highly aesthetic lifestyle and aesthetic integrations.',
      tag: 'Niches'
    },
    {
      id: 'metric-3',
      icon: <Sliders className="h-6 w-6" />,
      title: 'Personalized Campaign Strategy',
      description: 'No template plans. We write customized briefs, match creators to budget, and map out unique brand storylines.',
      tag: 'Strategy'
    },
    {
      id: 'metric-4',
      icon: <CheckCircle2 className="h-6 w-6" />,
      title: 'End-to-End Campaign Management',
      description: 'From sample shipments and contracts, to content approvals and deep performance reporting—we handle everything.',
      tag: 'Execution'
    }
  ];

  return (
    <section
      id="trust-section"
      className={`py-12 md:py-16 transition-all duration-300 relative border-t border-b ${
        darkMode 
          ? 'bg-slate-900/20 border-slate-800/40' 
          : 'bg-white border-slate-200/40'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Trusted By Grid Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-green-50 dark:bg-[#22C55E]/10 text-[#22C55E] border border-green-200/20 dark:border-transparent rounded-full text-xs font-bold uppercase tracking-tighter">
            <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
            The BillionEra Pledge
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-extrabold tracking-tight">
            Built on Absolute Trust & Verified Campaign Performance.
          </h2>
          <p className={`text-base leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            We bridge the gap between India’s highest-performing creators and fast-growing direct-to-consumer brands. Here is how we safeguard your brand authority and ad spend.
          </p>
        </div>

        {/* Dynamic Metric Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {trustMetrics.map((metric, idx) => (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`p-8 rounded-3xl border transition-all duration-300 relative overflow-hidden group hover:shadow-xl ${
                darkMode
                  ? 'bg-slate-900 border-slate-800/85 hover:border-[#22C55E]/40 shadow-black/20'
                  : 'bg-white border-slate-100 hover:border-[#22C55E]/40 shadow-sm shadow-slate-100'
              }`}
            >
              {/* Subtle background glow */}
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#22C55E]/5 rounded-full filter blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Card Header Info */}
              <div className="flex items-center justify-between mb-5">
                <div className="p-3 rounded-xl bg-[#22C55E]/10 text-[#22C55E] transition-transform group-hover:scale-110">
                  {metric.icon}
                </div>
                <span className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-md ${
                  darkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500'
                }`}>
                  {metric.tag}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-lg font-bold font-display leading-tight mb-2 group-hover:text-[#22C55E] transition-colors">
                {metric.title}
              </h3>
              <p className={`text-xs leading-relaxed ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                {metric.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Dynamic Live Trust Statistics Counter Bar */}
        <div className={`mt-16 p-8 rounded-3xl border flex flex-col md:flex-row items-center justify-around gap-8 text-center ${
          darkMode ? 'bg-slate-900 border-slate-850' : 'bg-white border-slate-100 shadow-sm'
        }`}>
          <div>
            <h4 className="text-4xl sm:text-5xl font-display font-black text-[#22C55E]">30+</h4>
            <p className={`text-xs font-mono uppercase tracking-wider mt-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>Verified Elite Creators</p>
          </div>
          <div className={`hidden md:block w-px h-12 ${darkMode ? 'bg-slate-800' : 'bg-slate-200'}`} />
          
          <div>
            <h4 className="text-4xl sm:text-5xl font-display font-black text-[#22C55E]">4+</h4>
            <p className={`text-xs font-mono uppercase tracking-wider mt-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>Specialized Industry Verticals</p>
          </div>
          <div className={`hidden md:block w-px h-12 ${darkMode ? 'bg-slate-800' : 'bg-slate-200'}`} />

          <div>
            <h4 className="text-4xl sm:text-5xl font-display font-black text-[#22C55E]">100%</h4>
            <p className={`text-xs font-mono uppercase tracking-wider mt-1.5 ${darkMode ? 'text-slate-400' : 'text-slate-555'}`}>Transparency & Performance</p>
          </div>
        </div>

      </div>
    </section>
  );
}
