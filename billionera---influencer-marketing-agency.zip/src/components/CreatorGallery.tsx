import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreatorItem } from '../types';
import { 
  Instagram, Search, MapPin, MessageSquare, Globe, 
  Award, Sparkles, X, Filter, ChevronDown, 
  TrendingUp, Download, Users, Star, ArrowUpRight, Check, Plus
} from 'lucide-react';

interface CreatorGalleryProps {
  darkMode: boolean;
  onNavigate: (sectionId: string) => void;
  creators: CreatorItem[];
  setCreators: React.Dispatch<React.SetStateAction<CreatorItem[]>>;
  onOpenAdmin: () => void;
}

export default function CreatorGallery({ darkMode, onNavigate, creators, setCreators, onOpenAdmin }: CreatorGalleryProps) {
  // State for search and filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNiche, setSelectedNiche] = useState('All');
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedFollowerRange, setSelectedFollowerRange] = useState('All');
  const [selectedEngagement, setSelectedEngagement] = useState('All');
  const [selectedLanguage, setSelectedLanguage] = useState('All');

  // State for active profile view
  const [activeCreator, setActiveCreator] = useState<CreatorItem | null>(null);

  // State for adding a creator review
  const [newBrandName, setNewBrandName] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [showReviewForm, setShowReviewForm] = useState(false);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCreator || !newBrandName.trim() || !newComment.trim()) return;

    const newReview = {
      id: `rev-${Date.now()}`,
      brandName: newBrandName.trim(),
      rating: newRating,
      comment: newComment.trim(),
      date: new Date().toISOString().split('T')[0]
    };

    const updatedCreator: CreatorItem = {
      ...activeCreator,
      reviews: [...(activeCreator.reviews || []), newReview]
    };

    setCreators(prev => prev.map(c => c.id === activeCreator.id ? updatedCreator : c));
    setActiveCreator(updatedCreator);

    // Reset form
    setNewBrandName('');
    setNewRating(5);
    setNewComment('');
    setShowReviewForm(false);
  };

  // Helper functions to parse metrics for proper numerical comparison
  const getFollowersNum = (followersStr: string) => {
    // e.g. "450K+" -> 450
    const clean = followersStr.toUpperCase().replace(/[^\d.]/g, '');
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  };

  const getEngagementNum = (engStr: string) => {
    // e.g. "8.4%" -> 8.4
    const clean = engStr.replace(/[^\d.]/g, '');
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  };

  // Get unique cities and languages from creators for dropdowns
  const availableCities = Array.from(new Set(creators.map(c => c.city).filter(Boolean))) as string[];
  
  const availableLanguages = Array.from(
    new Set(creators.flatMap(c => c.languages || []).filter(Boolean))
  ) as string[];

  // Filtering engine
  const filteredCreators = creators.filter((creator) => {
    // 1. Search filter (Name, Instagram Username, City)
    const searchString = `${creator.name} ${creator.instagramUsername || ''} ${creator.city || ''}`.toLowerCase();
    const matchesSearch = searchString.includes(searchTerm.toLowerCase());

    // 2. Niche filter (Fashion, Lifestyle, Food, Beauty)
    const matchesNiche = selectedNiche === 'All' || 
      creator.niche.toLowerCase() === selectedNiche.toLowerCase();

    // 3. City filter
    const matchesCity = selectedCity === 'All' || creator.city === selectedCity;

    // 4. Followers range filter
    let matchesFollowers = true;
    const fCount = getFollowersNum(creator.followers);
    if (selectedFollowerRange === '< 200K') {
      matchesFollowers = fCount < 200;
    } else if (selectedFollowerRange === '200K - 400K') {
      matchesFollowers = fCount >= 200 && fCount <= 400;
    } else if (selectedFollowerRange === '400K+') {
      matchesFollowers = fCount > 400;
    }

    // 5. Engagement threshold filter
    let matchesEngagement = true;
    const engVal = getEngagementNum(creator.engagement);
    if (selectedEngagement === '5%+') {
      matchesEngagement = engVal >= 5;
    } else if (selectedEngagement === '8%+') {
      matchesEngagement = engVal >= 8;
    } else if (selectedEngagement === '10%+') {
      matchesEngagement = engVal >= 10;
    }

    // 6. Language filter
    const matchesLanguage = selectedLanguage === 'All' || 
      (creator.languages && creator.languages.includes(selectedLanguage));

    return matchesSearch && matchesNiche && matchesCity && matchesFollowers && matchesEngagement && matchesLanguage;
  });

  // Dynamic clear filters helper
  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedNiche('All');
    setSelectedCity('All');
    setSelectedFollowerRange('All');
    setSelectedEngagement('All');
    setSelectedLanguage('All');
  };

  return (
    <section
      id="creators"
      className={`pt-6 pb-12 md:pt-8 md:pb-16 transition-colors duration-300 relative ${
        darkMode ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-4 max-w-3xl mx-auto mb-10 md:mb-12">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 bg-green-50 dark:bg-[#22C55E]/10 text-[#22C55E] border border-green-200/20 dark:border-transparent rounded-full text-xs font-bold uppercase tracking-widest"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
            Influencer Directory
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold tracking-tight"
          >
            Discover India's Top Vetted Creators
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className={`text-sm sm:text-base leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}
          >
            Browse high-performing influencers specializing in Fashion, Lifestyle, Food, and Beauty. 
            Use dynamic filters to target specific locations, audience size, and engagement metrics instantly.
          </motion.p>
        </div>

        {/* --- Directory Filter Controls Panel --- */}
        <div className={`p-6 sm:p-8 rounded-3xl border mb-12 shadow-xl ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            
            {/* Search Input Box */}
            <div className="lg:col-span-4 relative">
              <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1.5 ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                Search Creators
              </label>
              <div className="relative">
                <Search className={`absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 ${
                  darkMode ? 'text-slate-500' : 'text-slate-400'
                }`} />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by Name, Username, or City..."
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] ${
                    darkMode 
                      ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-600' 
                      : 'bg-slate-50 border-slate-200 text-slate-850 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>

            {/* Niche Quick Filter Buttons */}
            <div className="lg:col-span-8">
              <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1.5 ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                Niche / Category
              </label>
              <div className="flex flex-wrap gap-2">
                {['All', 'Fashion', 'Lifestyle', 'Food', 'Beauty'].map((niche) => (
                  <button
                    key={niche}
                    onClick={() => setSelectedNiche(niche)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedNiche === niche
                        ? 'bg-[#22C55E] text-slate-950 shadow-md shadow-green-900/10 scale-105'
                        : darkMode
                          ? 'bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-900'
                          : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {niche} {niche !== 'All' ? 'Creators' : ''}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Sub Dropdown Filters Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-6 mt-6 border-t border-slate-800/10 dark:border-slate-800/60">
            
            {/* City Filter */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">City</label>
              <div className="relative">
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] appearance-none cursor-pointer ${
                    darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <option value="All">All Cities (India)</option>
                  {availableCities.map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 pointer-events-none text-slate-500" />
              </div>
            </div>

            {/* Followers Range Filter */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Audience Size</label>
              <div className="relative">
                <select
                  value={selectedFollowerRange}
                  onChange={(e) => setSelectedFollowerRange(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] appearance-none cursor-pointer ${
                    darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <option value="All">All Followers</option>
                  <option value="< 200K">&lt; 200K Followers</option>
                  <option value="200K - 400K">200K - 400K Followers</option>
                  <option value="400K+">400K+ Followers</option>
                </select>
                <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 pointer-events-none text-slate-500" />
              </div>
            </div>

            {/* Engagement Rate Filter */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Engagement Rate</label>
              <div className="relative">
                <select
                  value={selectedEngagement}
                  onChange={(e) => setSelectedEngagement(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] appearance-none cursor-pointer ${
                    darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <option value="All">All Rates</option>
                  <option value="5%+">5%+ Engagement</option>
                  <option value="8%+">8%+ Engagement</option>
                  <option value="10%+">10%+ Engagement</option>
                </select>
                <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 pointer-events-none text-slate-500" />
              </div>
            </div>

            {/* Language Filter */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Languages</label>
              <div className="relative">
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E] appearance-none cursor-pointer ${
                    darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <option value="All">All Languages</option>
                  {availableLanguages.map(lang => (
                    <option key={lang} value={lang}>{lang}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 pointer-events-none text-slate-500" />
              </div>
            </div>

          </div>

          {/* Active Filters Row */}
          {(searchTerm || selectedNiche !== 'All' || selectedCity !== 'All' || selectedFollowerRange !== 'All' || selectedEngagement !== 'All' || selectedLanguage !== 'All') && (
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-dashed border-slate-800/10 dark:border-slate-800/40">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Active Filters:</span>
                
                {selectedNiche !== 'All' && (
                  <span className="px-2.5 py-1 rounded-lg bg-[#22C55E]/10 text-[#22C55E] text-[10px] font-bold">
                    Niche: {selectedNiche}
                  </span>
                )}
                {selectedCity !== 'All' && (
                  <span className="px-2.5 py-1 rounded-lg bg-[#22C55E]/10 text-[#22C55E] text-[10px] font-bold">
                    City: {selectedCity}
                  </span>
                )}
                {selectedFollowerRange !== 'All' && (
                  <span className="px-2.5 py-1 rounded-lg bg-[#22C55E]/10 text-[#22C55E] text-[10px] font-bold">
                    Followers: {selectedFollowerRange}
                  </span>
                )}
                {selectedEngagement !== 'All' && (
                  <span className="px-2.5 py-1 rounded-lg bg-[#22C55E]/10 text-[#22C55E] text-[10px] font-bold">
                    Engagement: {selectedEngagement}
                  </span>
                )}
                {selectedLanguage !== 'All' && (
                  <span className="px-2.5 py-1 rounded-lg bg-[#22C55E]/10 text-[#22C55E] text-[10px] font-bold">
                    Lang: {selectedLanguage}
                  </span>
                )}
                {searchTerm && (
                  <span className="px-2.5 py-1 rounded-lg bg-slate-500/10 text-slate-400 text-[10px] font-bold">
                    Query: "{searchTerm}"
                  </span>
                )}
              </div>

              <button
                onClick={handleClearFilters}
                className="text-xs font-bold text-red-500 hover:text-red-400 transition-colors cursor-pointer flex items-center gap-1"
              >
                <X className="h-3 w-3" /> Clear All Filters
              </button>
            </div>
          )}

        </div>

        {/* --- Dynamic Search & Filter Results Grid --- */}
        <AnimatePresence mode="wait">
          {filteredCreators.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {filteredCreators.map((creator, index) => (
                <motion.div
                  key={creator.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.3) }}
                  className={`rounded-3xl border overflow-hidden flex flex-col justify-between group transition-all duration-300 relative hover:shadow-2xl hover:border-[#22C55E]/20 ${
                    darkMode
                      ? 'bg-slate-900 border-slate-800/80 shadow-black/10'
                      : 'bg-white border-slate-200/80 shadow-sm'
                  }`}
                >
                  
                  {/* Card Visual Header */}
                  <div className="relative aspect-[4/5] overflow-hidden bg-slate-950/20">
                    <img
                      referrerPolicy="no-referrer"
                      src={creator.image}
                      alt={creator.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />

                    {/* Gradient Overlay for visual read of badges */}
                    <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />

                    {/* Floating City Badge */}
                    {creator.city && (
                      <div className="absolute top-3 left-3 z-10">
                        <span className="px-2.5 py-1 rounded-lg bg-black/70 text-white backdrop-blur-xs flex items-center gap-1 text-[10px] font-bold border border-white/10 shadow-lg">
                          <MapPin className="h-3 w-3 text-[#22C55E]" />
                          {creator.city}
                        </span>
                      </div>
                    )}

                    {/* Floating Niche / Category Badge */}
                    <div className="absolute bottom-3 left-3 z-10">
                      <span className="px-2.5 py-1 rounded-lg bg-[#22C55E] text-slate-950 text-[10px] font-mono font-bold uppercase tracking-wider shadow-md">
                        {creator.niche}
                      </span>
                    </div>

                    {/* Instagram Quick Link Icon overlay */}
                    {creator.instagramUrl && (
                      <a
                        href={creator.instagramUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="absolute top-3 right-3 z-10 p-2 rounded-xl bg-black/70 text-white backdrop-blur-xs border border-white/10 hover:text-pink-400 hover:border-pink-500/30 transition-all hover:scale-110 cursor-pointer"
                        title="View Instagram Handle"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Instagram className="h-4 w-4" />
                      </a>
                    )}
                  </div>

                  {/* Card Details */}
                  <div className="p-5.5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1 text-left">
                      <h3 className="font-display font-extrabold text-lg leading-tight group-hover:text-[#22C55E] transition-all">
                        {creator.name}
                      </h3>
                      {creator.instagramUsername && (
                        <p className="text-xs font-mono font-semibold text-slate-400 hover:text-[#22C55E] transition-all flex items-center gap-1">
                          @{creator.instagramUsername}
                        </p>
                      )}
                      
                      {/* Short Bio */}
                      {creator.bio && (
                        <p className={`text-[11px] leading-relaxed mt-2 line-clamp-2 ${
                          darkMode ? 'text-slate-400' : 'text-slate-500'
                        }`}>
                          {creator.bio}
                        </p>
                      )}

                      {/* Display Languages */}
                      {creator.languages && creator.languages.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-2">
                          {creator.languages.map(lang => (
                            <span 
                              key={lang} 
                              className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                darkMode ? 'bg-slate-950 text-slate-400 border border-slate-800' : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {lang}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Key Metrics Dashboard */}
                    <div className={`p-3 rounded-2xl grid grid-cols-2 gap-2 text-center border ${
                      darkMode ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div>
                        <p className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">Followers</p>
                        <p className="font-extrabold font-display text-base text-[#22C55E] mt-0.5">{creator.followers}</p>
                      </div>
                      <div className="border-l border-slate-200 dark:border-slate-850">
                        <p className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">Engagement</p>
                        <p className="font-extrabold font-display text-base text-[#22C55E] mt-0.5">{creator.engagement}</p>
                      </div>
                    </div>

                    {/* Action Button to Open Profile Sheet */}
                    <button
                      onClick={() => setActiveCreator(creator)}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.02] active:scale-[0.98] ${
                        darkMode 
                          ? 'bg-slate-800 text-white hover:bg-slate-700' 
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      <Users className="h-3.5 w-3.5 text-[#22C55E]" />
                      View Full Profile
                    </button>
                  </div>

                </motion.div>
              ))}
            </div>
          ) : (
            /* Wiped / Empty State */
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              className={`p-12 rounded-3xl border text-center max-w-2xl mx-auto space-y-6 ${
                darkMode ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200 shadow-md'
              }`}
            >
              <div className="w-16 h-16 rounded-full bg-[#22C55E]/10 flex items-center justify-center text-[#22C55E] mx-auto animate-pulse">
                <Sparkles className="h-8 w-8" />
              </div>
              <div className="space-y-2">
                <h3 className="font-display font-extrabold text-xl">No Vetted Creators Match</h3>
                <p className={`text-sm leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  No creators match your active search or filter selection. Try adjusting filters or searching for another location.
                </p>
              </div>
              <button
                onClick={handleClearFilters}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#22C55E] hover:bg-emerald-500 text-slate-950 rounded-2xl text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#22C55E]/15 cursor-pointer"
              >
                Clear Search & Filters
              </button>
            </motion.div>
          )}
        </AnimatePresence>

      </div>

      {/* --- CREATOR PROFILE PAGE / DETAILED VIEW SHEET (MODAL) --- */}
      <AnimatePresence>
        {activeCreator && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveCreator(null)}
              className="fixed inset-0 bg-black/85 backdrop-blur-sm"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3 }}
              className={`relative w-full max-w-4xl rounded-3xl border overflow-hidden shadow-2xl z-10 ${
                darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              
              {/* Close Button */}
              <button
                onClick={() => setActiveCreator(null)}
                className={`absolute top-4 right-4 z-20 p-2 rounded-full transition-all cursor-pointer ${
                  darkMode ? 'bg-slate-950/80 text-slate-400 hover:text-white' : 'bg-slate-100 text-slate-500 hover:text-slate-900'
                }`}
              >
                <X className="h-5 w-5" />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12">
                
                {/* Left Side: Large Visuals Panel */}
                <div className="md:col-span-5 relative bg-slate-950 aspect-[4/5] md:aspect-auto md:min-h-[500px]">
                  <img
                    referrerPolicy="no-referrer"
                    src={activeCreator.image}
                    alt={activeCreator.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent pointer-events-none" />

                  {/* Badges Overlay */}
                  <div className="absolute bottom-6 left-6 space-y-2 text-left">
                    <span className="inline-block px-3 py-1 rounded-lg bg-[#22C55E] text-slate-950 text-xs font-mono font-bold uppercase tracking-wider">
                      {activeCreator.niche} Niche
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-display font-extrabold text-white">
                      {activeCreator.name}
                    </h3>
                    {activeCreator.instagramUsername && (
                      <p className="text-sm font-mono text-slate-300">
                        @{activeCreator.instagramUsername}
                      </p>
                    )}
                  </div>
                </div>

                {/* Right Side: High-density Analytics Details Panel */}
                <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6 text-left max-h-[90vh] md:max-h-none overflow-y-auto">
                  
                  {/* Bio & Links Header */}
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/10 dark:border-slate-800/60 pb-4">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Verified Location</span>
                        <p className="text-sm font-semibold flex items-center gap-1.5 mt-0.5">
                          <MapPin className="h-4 w-4 text-[#22C55E]" />
                          {activeCreator.city || 'India'}
                        </p>
                      </div>

                      {activeCreator.instagramUrl && (
                        <a
                          href={activeCreator.instagramUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-pink-500/10 text-pink-500 dark:text-pink-400 border border-pink-500/20 hover:bg-pink-500 hover:text-white transition-all"
                        >
                          <Instagram className="h-3.5 w-3.5" />
                          <span>View Instagram</span>
                          <ArrowUpRight className="h-3 w-3" />
                        </a>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Personal Creator Bio</span>
                      <p className={`text-xs leading-relaxed ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                        {activeCreator.bio || "This vetted BillionEra content creator produces high-performing premium content specifically designed to engage and activate buyers in urban Indian markets."}
                      </p>
                    </div>
                  </div>

                  {/* Key Stats Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'}`}>
                      <p className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-500">Instagram Followers</p>
                      <h4 className="text-xl sm:text-2xl font-display font-extrabold text-[#22C55E] mt-1">{activeCreator.followers}</h4>
                    </div>
                    <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'}`}>
                      <p className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-500">Engagement Rate</p>
                      <h4 className="text-xl sm:text-2xl font-display font-extrabold text-[#22C55E] mt-1">{activeCreator.engagement}</h4>
                    </div>
                  </div>

                  {/* Languages Section */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Languages Spoken</span>
                    <div className="flex flex-wrap gap-2">
                      {activeCreator.languages && activeCreator.languages.length > 0 ? (
                        activeCreator.languages.map(lang => (
                          <span 
                            key={lang} 
                            className={`px-3 py-1 rounded-lg text-xs font-bold border ${
                              darkMode ? 'bg-slate-950 border-slate-850 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-600'
                            }`}
                          >
                            {lang}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-slate-400">English, Hindi</span>
                      )}
                    </div>
                  </div>

                  {/* Previous Brand Collabs */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Previous Brand Collaborations</span>
                    <p className={`text-xs font-semibold ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                      {activeCreator.recentBrand || "Available upon request (Myntra, Ajio, Nykaa, etc.)"}
                    </p>
                  </div>

                  {/* Dynamic Hardened Demographic Insights */}
                  <div className="space-y-3.5 border-t border-slate-850 pt-4 mt-2">
                    <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Audience Demographic Analysis</h5>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div className="space-y-2">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Age 18-24 (Primary)</span>
                          <span className="font-bold text-[#22C55E]">64%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-[#22C55E] rounded-full" style={{ width: '64%' }} />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Gender (Female Ratio)</span>
                          <span className="font-bold text-[#22C55E]">72%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-[#22C55E] rounded-full" style={{ width: '72%' }} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Brand Reviews & Verifications */}
                  <div className="space-y-3 border-t border-slate-800/10 dark:border-slate-800/60 pt-4 mt-2">
                    <div className="flex items-center justify-between">
                      <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        Brand Campaigns & Reviews
                      </h5>
                      {activeCreator.reviews && activeCreator.reviews.length > 0 && (
                        <div className="flex items-center gap-1 text-xs">
                          <span className="font-extrabold text-[#22C55E]">
                            {(activeCreator.reviews.reduce((acc, r) => acc + r.rating, 0) / activeCreator.reviews.length).toFixed(1)}
                          </span>
                          <Star className="h-3.5 w-3.5 fill-[#22C55E] text-[#22C55E]" />
                          <span className="text-slate-400">({activeCreator.reviews.length})</span>
                        </div>
                      )}
                    </div>

                    {/* Review list */}
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {activeCreator.reviews && activeCreator.reviews.length > 0 ? (
                        activeCreator.reviews.map((rev) => (
                          <div 
                            key={rev.id} 
                            className={`p-3 rounded-xl border text-xs text-left ${
                              darkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-150'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <span className="font-bold text-[#22C55E]">{rev.brandName}</span>
                              <div className="flex items-center gap-1 shrink-0">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`h-3 w-3 ${
                                      i < rev.rating 
                                        ? 'fill-amber-400 text-amber-400' 
                                        : 'text-slate-600'
                                    }`} 
                                  />
                                ))}
                                <span className="text-[9px] text-slate-500 font-mono ml-1">{rev.date}</span>
                              </div>
                            </div>
                            <p className={`${darkMode ? 'text-slate-300' : 'text-slate-600'} text-[11px] leading-relaxed`}>
                              "{rev.comment}"
                            </p>
                          </div>
                        ))
                      ) : (
                        <p className="text-[11px] text-slate-500 italic">No brand reviews published yet. Be the first to leave a review!</p>
                      )}
                    </div>

                    {/* Leave Review Form */}
                    <div className="pt-2">
                      {!showReviewForm ? (
                        <button
                          type="button"
                          onClick={() => setShowReviewForm(true)}
                          className={`w-full py-2 border border-dashed rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            darkMode 
                              ? 'border-slate-800 hover:border-[#22C55E]/60 text-slate-300 bg-slate-900/40 hover:bg-slate-950/40' 
                              : 'border-slate-300 hover:border-[#22C55E]/60 text-slate-600 bg-slate-50 hover:bg-slate-100'
                          }`}
                        >
                          <Plus className="h-3.5 w-3.5 text-[#22C55E]" />
                          Write a Brand Review
                        </button>
                      ) : (
                        <form onSubmit={handleAddReview} className={`p-4 rounded-xl border space-y-3 text-left ${
                          darkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-100 border-slate-200'
                        }`}>
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold uppercase text-[#22C55E]">New Verified Review</span>
                            <button 
                              type="button" 
                              onClick={() => setShowReviewForm(false)} 
                              className="text-[10px] text-slate-500 hover:text-slate-300"
                            >
                              Cancel
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold uppercase text-slate-500 block">Brand / Company Name</label>
                              <input
                                type="text"
                                required
                                placeholder="e.g. Nykaa, Sugar Cosmetics"
                                value={newBrandName}
                                onChange={(e) => setNewBrandName(e.target.value)}
                                className={`w-full px-2.5 py-1.5 rounded-lg text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/40 ${
                                  darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200'
                                }`}
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold uppercase text-slate-500 block">Rating</label>
                              <select
                                value={newRating}
                                onChange={(e) => setNewRating(Number(e.target.value))}
                                className={`w-full px-2.5 py-1.5 rounded-lg text-xs border focus:outline-none focus:ring-1 focus:ring-[#22C55E]/40 ${
                                  darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200'
                                }`}
                              >
                                <option value="5">⭐⭐⭐⭐⭐ (5 Stars)</option>
                                <option value="4">⭐⭐⭐⭐ (4 Stars)</option>
                                <option value="3">⭐⭐⭐ (3 Stars)</option>
                                <option value="2">⭐⭐ (2 Stars)</option>
                                <option value="1">⭐ (1 Star)</option>
                              </select>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[9px] font-bold uppercase text-slate-500 block">Review Comment</label>
                            <textarea
                              required
                              rows={2}
                              placeholder="Describe your collaboration ROI, delivery speed, and content quality..."
                              value={newComment}
                              onChange={(e) => setNewComment(e.target.value)}
                              className={`w-full px-2.5 py-1.5 rounded-lg text-xs border resize-none focus:outline-none focus:ring-1 focus:ring-[#22C55E]/40 ${
                                darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200'
                              }`}
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full py-2 bg-[#22C55E] hover:bg-emerald-500 text-slate-950 text-xs font-bold rounded-lg transition-all uppercase tracking-wider cursor-pointer"
                          >
                            Publish Verified Review
                          </button>
                        </form>
                      )}
                    </div>
                  </div>

                  {/* Lead Generation WhatsApp Box */}
                  <div className={`p-4 rounded-2xl border border-dashed mt-4 space-y-3 ${
                    darkMode 
                      ? 'bg-emerald-950/10 border-emerald-500/20' 
                      : 'bg-green-50/50 border-green-200'
                  }`}>
                    <p className={`text-xs font-semibold text-center ${darkMode ? 'text-emerald-400/90' : 'text-emerald-700'}`}>
                      Interested in collaborating with this creator? Contact BillionEra on WhatsApp.
                    </p>
                    <a
                      href={`https://wa.me/919576751269?text=Hi%20BillionEra,%20I'm%20interested%20in%20collaborating%20with%20creator%20${encodeURIComponent(activeCreator.name)}%20(@${encodeURIComponent(activeCreator.instagramUsername || '')})%20for%20our%20brand%20campaign.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 px-4 bg-[#22C55E] hover:bg-emerald-600 text-white font-bold rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] shadow-lg shadow-green-950/10 cursor-pointer"
                    >
                      <MessageSquare className="h-4.5 w-4.5" />
                      <span>Inquire about {activeCreator.name}</span>
                    </a>
                  </div>

                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
