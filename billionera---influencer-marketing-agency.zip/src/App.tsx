import React, { useState, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import Header from './components/Header';
import Hero from './components/Hero';
import TrustSection from './components/TrustSection';
import CreatorGallery from './components/CreatorGallery';
import Testimonials from './components/Testimonials';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import AdminPanel from './components/AdminPanel';

import { CREATORS, SERVICES, TESTIMONIALS, FAQS } from './data';
import { CreatorItem, ServiceItem, TestimonialItem, FAQItem } from './types';

const DEFAULT_SETTINGS = {
  heroBadge: "Influencer Directory India",
  heroTitle: "Find the Right Influencer for Your Brand.",
  heroDescription: "Discover carefully selected creators across Fashion, Lifestyle, Food, and Beauty. Browse creator profiles, compare their audience, and connect with BillionEra to start your next influencer campaign.",
  contactEmail: "billioneraanr@gmail.com",
  contactPhone: "+919576751269",
  contactInstagram: "https://www.instagram.com/anr.billionera?igsh=MWE2ejJldDlwZnVhYQ=="
};

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Core dynamic database states with localStorage recovery
  const [creators, setCreators] = useState<CreatorItem[]>(() => {
    try {
      const saved = localStorage.getItem('billionera_creators_v3');
      return saved ? JSON.parse(saved) : CREATORS;
    } catch {
      return CREATORS;
    }
  });

  const [services, setServices] = useState<ServiceItem[]>(() => {
    try {
      const saved = localStorage.getItem('billionera_services');
      return saved ? JSON.parse(saved) : SERVICES;
    } catch {
      return SERVICES;
    }
  });

  const [testimonials, setTestimonials] = useState<TestimonialItem[]>(() => {
    try {
      const saved = localStorage.getItem('billionera_testimonials');
      return saved ? JSON.parse(saved) : TESTIMONIALS;
    } catch {
      return TESTIMONIALS;
    }
  });

  const [faqs, setFaqs] = useState<FAQItem[]>(() => {
    try {
      const saved = localStorage.getItem('billionera_faqs');
      return saved ? JSON.parse(saved) : FAQS;
    } catch {
      return FAQS;
    }
  });

  const [siteSettings, setSiteSettings] = useState(() => {
    try {
      const saved = localStorage.getItem('billionera_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Sync state variables to localStorage safely
  // Utilizing stringified JSON dependency arrays to comply strictly with the stabilized dependency rules
  const creatorsString = JSON.stringify(creators);
  const servicesString = JSON.stringify(services);
  const testimonialsString = JSON.stringify(testimonials);
  const faqsString = JSON.stringify(faqs);
  const siteSettingsString = JSON.stringify(siteSettings);

  useEffect(() => {
    localStorage.setItem('billionera_creators_v3', creatorsString);
  }, [creatorsString]);

  useEffect(() => {
    localStorage.setItem('billionera_services', servicesString);
  }, [servicesString]);

  useEffect(() => {
    localStorage.setItem('billionera_testimonials', testimonialsString);
  }, [testimonialsString]);

  useEffect(() => {
    localStorage.setItem('billionera_faqs', faqsString);
  }, [faqsString]);

  useEffect(() => {
    localStorage.setItem('billionera_settings', siteSettingsString);
  }, [siteSettingsString]);

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className={`transition-all duration-300 min-h-screen ${
      darkMode ? 'dark bg-slate-950 text-white font-sans' : 'bg-slate-50 text-slate-900 font-sans'
    }`}>
      {/* Navigation Header */}
      <Header 
        darkMode={darkMode} 
        setDarkMode={setDarkMode} 
        onNavigate={handleNavigate} 
        onOpenAdmin={() => setIsAdminOpen(true)} 
      />

      {/* Main Layout Sections */}
      <main className="relative overflow-hidden">
        
        {/* Hero Section */}
        <Hero 
          darkMode={darkMode} 
          onNavigate={handleNavigate} 
          siteSettings={siteSettings} 
        />

        {/* 1st Part: INFLUENCER DIRECTORY (Live Filterable Creator Showcase Panel) */}
        <CreatorGallery 
          darkMode={darkMode} 
          onNavigate={handleNavigate} 
          creators={creators} 
          setCreators={setCreators}
          onOpenAdmin={() => setIsAdminOpen(true)}
        />

        {/* 2nd Part: THE BILLIONERA PLEDGE (Trust Indicators Metric Panel) */}
        <TrustSection darkMode={darkMode} />

        {/* 3rd Part: Success Story designed step-by-step (Customer Testimonials & Case Study) */}
        <Testimonials 
          darkMode={darkMode} 
          testimonials={testimonials} 
          onAddTestimonial={(newReview) => setTestimonials([newReview, ...testimonials])}
        />

        {/* Conversion Brief intake & Budget Estimator Form */}
        <ContactSection 
          darkMode={darkMode} 
          siteSettings={siteSettings} 
        />

      </main>

      {/* Standard multi-column site footer */}
      <Footer 
        darkMode={darkMode} 
        onNavigate={handleNavigate} 
        siteSettings={siteSettings} 
      />

      {/* Slide-over admin panel for content editing & management */}
      <AdminPanel 
        isOpen={isAdminOpen} 
        onClose={() => setIsAdminOpen(false)} 
        darkMode={darkMode}
        creators={creators}
        setCreators={setCreators}
        services={services}
        setServices={setServices}
        testimonials={testimonials}
        setTestimonials={setTestimonials}
        faqs={faqs}
        setFaqs={setFaqs}
        siteSettings={siteSettings}
        setSiteSettings={setSiteSettings}
      />

      {/* Persistent Floating Fixed WhatsApp Button on Every Page */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
        className="fixed bottom-6 right-6 z-40"
      >
        <a
          href={`https://wa.me/919576751269?text=Hi%20BillionEra,%20I'm%20interested%20in%20launching%20an%20influencer%20campaign%20with%20your%20creators.`}
          target="_blank"
          rel="noopener noreferrer"
          className="relative flex items-center justify-center w-14 h-14 bg-[#22C55E] text-white rounded-full shadow-2xl hover:bg-emerald-500 hover:scale-110 active:scale-95 transition-all group cursor-pointer"
          title="Contact BillionEra on WhatsApp"
        >
          {/* Pulsing ring animation */}
          <span className="absolute inset-0 rounded-full bg-[#22C55E]/40 animate-ping pointer-events-none" />
          
          <MessageCircle className="h-7 w-7 fill-white/10" />

          {/* Elegant hover tooltip */}
          <span className="absolute right-16 px-3 py-1.5 bg-slate-900 text-white text-[11px] font-bold rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap border border-slate-800 shadow-md">
            Contact on WhatsApp
          </span>
        </a>
      </motion.div>
    </div>
  );
}
